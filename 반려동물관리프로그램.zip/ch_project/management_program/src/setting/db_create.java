package setting;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class db_create {
	
	Statement st = null;
	Connection con = null;
	
	db_create(){
		
		
		try {
			con = dbconnect.getdbconnect();
			st = con.createStatement();
			
			st.executeUpdate("create database if not exists petDB");
			System.out.println("Create Database OK.");
		}
		
		catch(SQLException se) {
			se.getStackTrace();
		}
	
	}
}
