package setting;

public class Run {

	public static void main(String[] args) {
		new db_create();
		new create_table();
		new insert_data();
	}

}
