package setting;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class create_table {

	Statement st = null;
	Connection con = null;
	
	create_table(){
		try {
			con = dbconnect.getdbconnect();
			st = con.createStatement();
			
			st.executeUpdate("create table if not exists user(\r\n" + 
					"userCode varchar(7) not null,\r\n" + 
					"name varchar(20) null,\r\n" + 
					"birth date,\r\n" + 
					"address varchar(100) null,\r\n" + 
					"password varchar(20) null,\r\n" + 
					"primary key(userCode));");
			
			st.executeUpdate("create table if not exists pet(\r\n" + 
					"petCode int not null auto_increment,\r\n" + 
					"petName varchar(20) null,\r\n" + 
					"gender varchar(20) null,\r\n" + 
					"classification varchar(20) null,\r\n" + 
					"breeds varchar(20) null,\r\n" + 
					"birth date,\r\n" + 
					"userCode varchar(7),\r\n" + 
					"primary key(petCode));");
			
			st.executeUpdate("create table if not exists diary(\r\n" + 
					"number int not null auto_increment,\r\n" + 
					"userCode varchar(7) not null,\r\n" + 
					"day date,\r\n" + 
					"memo varchar(150) null,\r\n" + 
					"primary key(number));");
			
			st.executeUpdate("create table if not exists HealthNote(\r\n" + 
					"number int not null auto_increment,\r\n" + 
					"vaccine varchar(20) null,\r\n" + 
					"lastdate date,\r\n" + 
					"duedate date,\r\n" + 
					"petCode int not null,\r\n" + 
					"primary key(number));");
			
			st.executeUpdate("create table if not exists profile(\r\n" + 
					"petCode int not null,\r\n" + 
					"depth int null,\r\n" + 
					"length int null,\r\n" + 
					"weight int null,\r\n" + 
					"primary key(petCode));");
			
			System.out.println("Create Table OK.");
		}
		
		catch(SQLException se) {
			se.getStackTrace();
		}
	}
	

}
