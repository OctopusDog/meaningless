package setting;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.plaf.synth.SynthSeparatorUI;

public class dbconnect {
	public static Connection getdbconnect(){
			
		String url = "jdbc:mysql://localhost:3306/petDB?useUnicode=true&characterEncoding=utf8";
		String id = "root";
		String pw = "1234";
		Connection con = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, id, pw);
			System.out.println("Connect");
			return con;
		}
		
		catch(ClassNotFoundException e) {
			System.out.println("Not Found");
		}
		
		catch(SQLException e) {
			e.printStackTrace();
		}return null;
	}
}
