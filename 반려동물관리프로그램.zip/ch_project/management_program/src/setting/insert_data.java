package setting;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class insert_data {
	
	Connection con = null;
	PreparedStatement psmt = null;
	
	Scanner read_file;
	
	insert_data(){
		
		String tables [] = {"user", "pet", "HealthNote", "profile"};
		String line = null;
		String tmp = null;
		
		String insert_member = "insert into user values (?, ?, ?, ?, ?)";
		String insert_cuisine = "insert into pet values (?, ?, ?, ?, ?, ?, ?)";
		String insert_meal = "insert into HealthNote values(?, ?, ?, ?, ?)";
		String insert_orderlist = "insert into profile values(?, ?, ?, ?)";
		
		try {
			con = dbconnect.getdbconnect();
			
			for(int i = 0; i<tables.length; i++) {
				
				if(tables[i].equals("user")) {
					tmp = insert_member;
				}
				
				if(tables[i].equals("pet")) {
					tmp = insert_cuisine;
				}
				
				if(tables[i].equals("HealthNote")) {
					tmp = insert_meal;
				}
				
				if(tables[i].equals("profile")) {
					tmp = insert_orderlist;
				}
				
				read_file = new Scanner(new FileInputStream("DataFiles\\"+tables[i]+".txt"));
				
				line = read_file.nextLine();
				
				while(read_file.hasNext()) {
					String [] buffer = read_file.nextLine().split("\t");
					psmt = con.prepareStatement(tmp);
					
						for(int j = 0; j<buffer.length; j ++) {
							psmt.setString(j+1, buffer[j]);
						}
						
						psmt.executeUpdate();
					
				}
				
			}
			System.out.println("Insert data Ok.");
			
		}
		
		catch(SQLException e) {
			System.out.println("SQL");
			e.printStackTrace();
		}
		
		catch(FileNotFoundException fne) {
			System.out.println("File Not Found");
		}
		
	}
}
