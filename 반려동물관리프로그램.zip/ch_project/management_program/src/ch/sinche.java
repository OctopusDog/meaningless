package ch;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import setting.dbconnect;

public class sinche extends JFrame{
	
	JPanel top, bottom;
	JPanel top_left, top_right;
	
	JButton select, edit, delete, cansel;
	
	JLabel name = new JLabel("이름 : ");
	JLabel jt_name = new JLabel();
	
	JLabel gender = new JLabel("성 별 : ");
	JLabel jt_gender = new JLabel();
	
	JLabel birth = new JLabel("생년월일 : "); 
	JLabel jt_birth = new JLabel();
	
	JLabel breeds = new JLabel("품 종 : ");
	JLabel jt_breeds = new JLabel();

	JLabel depth = new JLabel("체고: ");
	JLabel jt_depth= new JLabel();
	
	JLabel length = new JLabel("체장 : ");
	JLabel jt_length = new JLabel();
	
	JLabel weight = new JLabel("몸무게: ");
	JLabel jt_weight = new JLabel();
	
	
	Statement st =  null;
	Connection con = null;
	
	PreparedStatement psmt = null;
	String code = null;
	
	sinche(String a1,String a2, String a3, String a4, String a5, String a6){
		setTitle("프로필");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		code = a1;
		
		top = new JPanel(new GridLayout(2,1));
		bottom = new JPanel(new FlowLayout());
		
		select = new JButton("갱신");
		edit = new JButton("수정");
		cansel = new JButton("닫기");
		
		bottom.add(select);
		bottom.add(edit);
		bottom.add(cansel);
		
		Font font = new Font("맑은 고딕", Font.PLAIN, 20);
		
		name.setFont(font);
		gender.setFont(font);
		birth.setFont(font);
		depth.setFont(font);
		length.setFont(font);
		weight.setFont(font);
		
		jt_name.setFont(font);
		jt_gender.setFont(font);
		jt_birth.setFont(font);
		jt_depth.setFont(font);
		jt_length.setFont(font);
		jt_weight.setFont(font);
		
		jt_name.setText(a2);
		jt_gender.setText(a3);
		jt_birth.setText(a6);
		jt_breeds.setText(a5);
		view();
		
		top.setLayout(new GridLayout(7,2));
		top.add(name);
		top.add(jt_name);
		top.add(gender);
		top.add(jt_gender);
		top.add(birth);
		top.add(jt_birth);
		top.add(depth);
		top.add(jt_depth);
		top.add(length);
		top.add(jt_length);
		top.add(weight);
		top.add(jt_weight);
		
		edit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String depht = jt_depth.getText();
				String length = jt_length.getText();
				String weight = jt_weight.getText();
				
				new sinche_edit(code, depht, length, weight);
			}
		});
		
		select.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view();
			}
		});
		

		cansel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
	
		c.add(top,BorderLayout.CENTER);
		c.add(bottom,BorderLayout.SOUTH);
		
		setSize(400, 500);
		setVisible(true);
	}
	
	private void view() {
		String sql = "select depth, length, weight from profile where petCode ="+"'"+code+"';";
		try {
			Connection con = dbconnect.getdbconnect();
			PreparedStatement psmt = con.prepareStatement(sql);
					
			ResultSet  rs = psmt.executeQuery(sql);
			
			while(rs.next()) {
					jt_depth.setText(rs.getString(1)+"cm");
					jt_length.setText(rs.getString(2)+"cm");
					jt_weight.setText(rs.getString(3)+"kg");
				}
					
			}
		
		catch(Exception ee) {
			 System.out.println(ee);
		  }
	   }
	}
