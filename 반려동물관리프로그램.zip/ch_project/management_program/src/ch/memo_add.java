package ch;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import setting.dbconnect;

public class memo_add extends JFrame{
	JLabel c_01, c_02, c_03, c_04,c_05;
	JPanel p1, p2, p3, p4, p5, p7;
	
	JTextField f1, f2, f3, f4;
	JTextArea f5;
	JButton c_add, c_exit;
	

	String db_01 = null;
	String db_02 = null;

	Statement st =  null;
	Connection con = null;
	
	PreparedStatement psmt = null;
	
	 memo_add(String petCode, String DB_id){
		setTitle("추가");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new GridLayout(5, 2));
				
		c_04 = new JLabel("날짜:");
		c_05 = new JLabel("메모:");
		
		
		p4 = new JPanel(new GridLayout(1, 2));
		p5 = new JPanel(new GridLayout(1, 2));
		p7 = new JPanel();
		

		f4 = new JTextField(10);
		f5 = new JTextArea();
		
		
		c_add = new JButton("추가");
		c_exit = new JButton("닫기");
		
		
		c_add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					con = dbconnect.getdbconnect();
					st = con.createStatement();
					psmt = con.prepareStatement("insert into diary values(null,?,?,?,?)");
					
			
					String day = f4.getText();
					String memo = f5.getText();
					
					
					psmt.setString(1, DB_id);
					psmt.setString(2, petCode);
					psmt.setString(3, day);
					psmt.setString(4, memo);
					
					int rs = psmt.executeUpdate();
					if(rs == 1) {
						JOptionPane.showMessageDialog(null, "완료되었습니다.", "메시지", JOptionPane.INFORMATION_MESSAGE);
					}
					
		
				} catch (SQLException e1) {
					JOptionPane.showMessageDialog(null, "오류!", "메시지", JOptionPane.ERROR_MESSAGE);
					System.out.println(e1);
				}							
			}
		});
		
		c_exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				
			}
		});
		
		
		
		
		p4.add(c_04);
		p4.add(f4);
		
		p5.add(c_05);
		p5.add(f5);
		
		p7.add(c_add);
		p7.add(c_exit);
		

		c.add(p4);
		c.add(p5);
		c.add(p7);
		
		setSize(450, 250);
		setVisible(true);
	 	}
	 
	 }
