package ch;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import setting.dbconnect;

public class login_form extends JFrame{
	JPanel p1, p2,p3;
	
	JLabel logo;
	JLabel name;
	JLabel pw;
	JLabel logo_label;
	JTextField name_tf;
	JPasswordField pw_tf;
	
	JButton login;
	JButton join;
	
	PreparedStatement psmt = null;
	Statement st = null;
	Connection con =null;
	
	String DB_id;
	String DB_pw;
	
	login_form(){
		setTitle("LOGIN");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new GridLayout(3, 1));
		
		p1 = new JPanel();
		p2 = new JPanel(new GridLayout(2,1));
		p3 = new JPanel();
		
		
		
		logo = new JLabel(new ImageIcon("img/lock.png"));
		logo_label = new JLabel("LOGIN");
		
		logo_label.setFont(new Font("맑은고딕", Font.BOLD, 30));
		p1.add(logo);
		p1.add(logo_label);

		
		name = new JLabel("ID   :");
		pw = new JLabel("PW :");
		
		name.setFont(new Font("맑은고딕", Font.BOLD, 20));
		pw.setFont(new Font("맑은고딕", Font.BOLD, 20));

		
		name_tf = new JTextField(8);
		pw_tf = new JPasswordField(8);
		
		
		p2.add(name);
		p2.add(name_tf);
		p2.add(pw);
		p2.add(pw_tf);

		
		login = new JButton(" 로그인 ");
		join = new JButton("회원가입");
		
		p3.add(login);
		p3.add(join);
		
		login.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					con = dbconnect.getdbconnect();
					st = con.createStatement();
				
					psmt = con.prepareStatement("select userCode, name from user Where userCode=? and password=?");
					
					DB_pw = new String(pw_tf.getPassword());
					DB_id = name_tf.getText();
					
					psmt.setString(1, DB_id);
					psmt.setString(2, DB_pw);
					
					ResultSet rs = psmt.executeQuery();
					
					if(rs.next()) {
						String name = rs.getString(2);
						
						JOptionPane.showMessageDialog(null, "로그인 성공!", "환영합니다 "+name+"님!", JOptionPane.INFORMATION_MESSAGE);
						new main_form(DB_id, name);
						dispose();
					}
					else if(name_tf.getText().equals("") || pw_tf.getText().equals("")) {
						JOptionPane.showMessageDialog(null, "빈칸이 존재 합니다!", "MESSAGE", JOptionPane.ERROR_MESSAGE);

					}
					
					else
					{
						JOptionPane.showMessageDialog(null, "로그인 실패!", "MESSAGE", JOptionPane.ERROR_MESSAGE);
					}
					

					
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
					
			}
		});
		
		join.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new join_form();
			}
		});
		
		c.add(p1);
		c.add(p2);
		c.add(p3,BorderLayout.SOUTH);
		
		setVisible(true);
		setSize(300, 270);
		
	}
}

