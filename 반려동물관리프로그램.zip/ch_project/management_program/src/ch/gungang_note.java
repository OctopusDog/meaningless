package ch;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import setting.dbconnect;

public class gungang_note extends JFrame{
	
	JTable jt;
	
	JPanel top, center ,bottom;
	JPanel top_left, top_right;
	
	JButton add, edit, delete, cansel, select;
	
	Vector<String> colData = new Vector<String>();
	Vector<Vector <String>>rowData = new Vector<Vector<String>>();
	
	Statement st =  null;
	Connection con = null;
	
	PreparedStatement psmt = null;
	
	String petCode = null;
		
	gungang_note(String a1,String a2, String a3, String a4, String a5, String a6){
		
		setTitle("접종기록");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new FlowLayout());
		
		colData.add("No");
		colData.add("백신명");
		colData.add("최종일");
		colData.add("예정일");

		jt = new JTable(rowData, colData);
		JScrollPane jps = new JScrollPane(jt);	
		
		petCode = a1;
		
		
		top = new JPanel(new GridLayout(2,1));
		top_left = new JPanel(new GridLayout(1, 1));
		top_right = new JPanel(new GridLayout(1, 1));
		bottom = new JPanel(new FlowLayout());
		center = new JPanel();
		
		select = new JButton("조회");
		add = new JButton("추가");
		edit = new JButton("수정");
		delete = new JButton("삭제");
		cansel = new JButton("닫기");
		
		bottom.add(select);
		bottom.add(add);
		bottom.add(edit);
		bottom.add(delete);
		bottom.add(cansel);
		
		center.add(jps);
		
		JLabel img4 = new JLabel(new ImageIcon("img/jack-russell-terrier.png"));

		JLabel name = new JLabel("이름 : ");
		JTextField jt_name = new JTextField(10);
		
		JLabel gender = new JLabel("   성 별 : ");
		JTextField jt_gender = new JTextField(10);
		
		JLabel birth = new JLabel("생년월일 : ");
		JTextField jt_birth = new JTextField(10);
		
		JLabel breeds = new JLabel("   품 종 : ");
		JTextField jt_breeds = new JTextField(10);
			
		jt_name.setText(a2);
		jt_gender.setText(a3);
		jt_birth.setText(a6);
		jt_breeds.setText(a5);
		
		top_left.add(name);
		top_left.add(jt_name);
		
		top_left.add(gender);
		top_left.add(jt_gender);
		
		top_right.add(birth);
		top_right.add(jt_birth);
		
		top_right.add(breeds);
		top_right.add(jt_breeds);
		
		jt_name.setEnabled(false);
		jt_gender.setEnabled(false);
		jt_birth.setEnabled(false);
		jt_breeds.setEnabled(false);
		
		top.add(top_left);
		top.add(top_right);
		
		view();
		
		select.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view();
			}
		});
		
		add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new gungang_add(petCode);	
			}
		});
		
		cansel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		edit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					int s = jt.getSelectedRow();
					
					String a1 = (String) jt.getValueAt(s, 0);
					String a2 = (String) jt.getValueAt(s, 1);
					String a3 = (String) jt.getValueAt(s, 2);
					String a4 = (String) jt.getValueAt(s, 3);
					new gungang_edit(a1,a2,a3,a4);
					
					}
				
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "테이블을 선택해주세요!", "메세지", JOptionPane.WARNING_MESSAGE);
					e1.printStackTrace();
					}
				}
		});
		
		delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String sql = "delete from healthnote where number = ?";
				try {
					
					Connection con = dbconnect.getdbconnect();
					PreparedStatement psmt = con.prepareStatement(sql);
					
					int s = jt.getSelectedRow();
					String numbering = (String) jt.getValueAt(s, 0);
					System.out.println(numbering);
					
					psmt.setString(1, numbering);
					int re = psmt.executeUpdate();
					
					if(re == 1) {
					JOptionPane.showMessageDialog(null, "삭제가 완료되었습니다.", "메시지", JOptionPane.QUESTION_MESSAGE);
					view();
					}
					
					

				} catch (SQLException e3) {
					e3.printStackTrace();
				}
			}
		});
		
		c.add(top,BorderLayout.NORTH);
		c.add(center,BorderLayout.CENTER);
		c.add(bottom,BorderLayout.SOUTH);
		
		setSize(540, 640);
		setVisible(true);
	}
	
	
	
	private void view() {
		String sql = "select number, vaccine, lastdate, duedate from healthnote where petCode = ?";
		
		try {
			rowData.clear();
			Connection con = dbconnect.getdbconnect();
			PreparedStatement stmt = con.prepareStatement(sql);
			
			stmt.setString(1, petCode);
			
			ResultSet  rs = stmt.executeQuery();
			
			
				while(rs.next()) {
					Vector<String> v = new Vector<String>();
					v.add(rs.getString(1));
					v.add(rs.getString(2));
					v.add(rs.getString(3));
					v.add(rs.getString(4));
	
					rowData.add(v);
				}		
			
			jt.updateUI();
		}catch(Exception ee) {
			System.out.println(ee);
			}
	}
	
}
