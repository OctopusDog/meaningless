package ch;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import setting.dbconnect;

public class sinche_edit extends JFrame{
	
	JTextField jt_code, jt_depth, jt_length, jt_weight;
	JButton update, close;

	 sinche_edit(String code, String depth, String length, String weight){
		setTitle("수정");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new GridLayout(5, 2));
		
		jt_code = new JTextField();
		jt_depth = new JTextField();
		jt_length = new JTextField();
		jt_weight = new JTextField();
		
		jt_code.setText(code);
		jt_code.setEnabled(false);
		
		jt_depth.setText(depth);
		jt_length.setText(length);
		jt_weight.setText(weight);
		
		update = new JButton("수정");
		close = new JButton("닫기");
		
		close.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		update.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String sql = "update profile set depth = ?, length = ?, weight = ? where petCode = ?";
					Connection con = dbconnect.getdbconnect();
					PreparedStatement psmt = con.prepareStatement(sql);
					
					String set_depth = jt_depth.getText();
					String set_length = jt_depth.getText();
					String set_weight = jt_weight.getText();
					String set_petCode = jt_code.getText();
					
					psmt.setString(1, set_depth);
					psmt.setString(2, set_length);
					psmt.setString(3, set_weight);
					psmt.setString(4, set_petCode);
					
					int rs = psmt.executeUpdate();
					
					if(rs == 1) {
						JOptionPane.showMessageDialog(null, "수정이 완료되었습니다!", "완료" ,JOptionPane.INFORMATION_MESSAGE);
						dispose();
					}
					else {
						JOptionPane.showMessageDialog(null, "수정 실패!", "오류" ,JOptionPane.ERROR_MESSAGE);

					}
					
				}
				
				catch(SQLException e2) {
					e2.printStackTrace();
				}
			}
		});
		
		c.add(new JLabel("펫코드"));
		c.add(jt_code);
		
		c.add(new JLabel("체고"));
		c.add(jt_depth);
		
		c.add(new JLabel("체장"));
		c.add(jt_length);
		
		c.add(new JLabel("몸무게"));
		c.add(jt_weight);
		
		c.add(update);
		c.add(close);
			
		
		setSize(450, 250);
		setVisible(true);
	 	}
}
