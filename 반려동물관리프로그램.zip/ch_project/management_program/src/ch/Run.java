package ch;

import javax.swing.UIManager;

public class Run {
	public static void main(String[] args) {
//		try {
//		    UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
//		} catch (Exception e) {
//		  e.printStackTrace();
//		}
		
		
		new login_form();
	}
}
