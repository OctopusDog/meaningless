package ch;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import setting.dbconnect;

public class memo_edit extends JFrame{
	JLabel c_01, c_02, c_03, c_04, c_05;
	JPanel p1, p2, p3, p4, p5, p7;
	
	JTextField f1, f2, f3, f4;
	JTextArea f5;
	JButton c_add, c_exit;
	

	String db_01 = null;
	String db_02 = null;

	Statement st =  null;
	Connection con = null;
	
	PreparedStatement psmt = null;
	
	 memo_edit(String a1, String a2, String a3, String a4, String a5){
		setTitle("수정");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new GridLayout(6, 2));
				
		c_01 = new JLabel("No:");
		c_02 = new JLabel("담당의사:");
		c_03 = new JLabel("펫코드:");
		c_04 = new JLabel("날짜:");
		c_05 = new JLabel("메모:");

		
		p1 = new JPanel(new GridLayout(1, 2));
		p2 = new JPanel(new GridLayout(1, 2));
		p3 = new JPanel(new GridLayout(1, 2));
		p4 = new JPanel(new GridLayout(1, 2));
		p5 = new JPanel(new GridLayout(1, 2));
		p7 = new JPanel();
		
		f1 = new JTextField(10);
		f1.setEnabled(false);
		f2 = new JTextField(10);
		f2.setEnabled(false);
		
		f3 = new JTextField(10);
		f3.setEnabled(false);
	
		f4 = new JTextField(10);
		
		f5 = new JTextArea();
		

		f1.setText(a1);
		f2.setText(a2);
		f3.setText(a3);
		f4.setText(a4);
		f5.setText(a5);
		
		c_add = new JButton("수정");
		c_exit = new JButton("닫기");
		
		c_add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					con = dbconnect.getdbconnect();
					st = con.createStatement();
					psmt = con.prepareStatement("update diary set day = ?, memo = ? where number = ?");
					
					String day = f4.getText();
					String memo = f5.getText();
					
					psmt.setString(1, day);
					psmt.setString(2, memo);
					psmt.setString(3, a1);
					
					int rs = psmt.executeUpdate();
					JOptionPane.showMessageDialog(null, "수정이 완료되었습니다.", "메시지", JOptionPane.INFORMATION_MESSAGE);
					
		
				} catch (SQLException e1) {
					JOptionPane.showMessageDialog(null, "오류!", "메시지", JOptionPane.ERROR_MESSAGE);
					System.out.println(e1);

				}								
			}
		});
		
		c_exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				
			}
		});
		
		
		
		p1.add(c_01);
		p1.add(f1);
		
		p2.add(c_02);
		p2.add(f2);
		
		p3.add(c_03);
		p3.add(f3);
		
		p4.add(c_04);
		p4.add(f4);
		
		p5.add(c_05);
		p5.add(f5);
		
		p7.add(c_add);
		p7.add(c_exit);
		
		c.add(p1);
		c.add(p2);
		c.add(p3);
		c.add(p4);
		c.add(p5);
		c.add(p7);
		
		setSize(600, 250);
		setVisible(true);
	 	}
	 }
