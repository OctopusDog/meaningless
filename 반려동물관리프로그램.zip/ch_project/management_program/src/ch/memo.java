package ch;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import setting.dbconnect;

public class memo extends JFrame{
	
	JTable jt;
	JPanel p1,p2;
	JTextField ta;
	JButton select ,add, edit, delete, cansel;
	
	Vector<String> colData = new Vector<String>();
	Vector<Vector <String>>rowData = new Vector<Vector<String>>();
	
	Statement st =  null;
	Connection con = null;
	
	PreparedStatement psmt = null;
	
	String petCode = null;
		
	memo(String a1, String DB_id){
		setTitle("다이어리");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new GridLayout(3, 1));
		
		petCode = a1;
		
		colData.add("No");
		colData.add("담당의사");
		colData.add("펫코드");
		colData.add("날짜");
		colData.add("메모");

		jt = new JTable(rowData, colData);
		JScrollPane jps = new JScrollPane(jt);		
		p2 = new JPanel();
		p1 = new JPanel();
		
		
				
		select = new JButton("조회");
		add = new JButton("추가");
		edit = new JButton("수정");
		delete = new JButton("삭제");
		cansel = new JButton("닫기");
		
		p1.add(select);
		p1.add(add);
		p1.add(edit);
		p1.add(delete);
		p1.add(cansel);
		
		view();
		
		delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					
					Connection con = dbconnect.getdbconnect();
					Statement stmt = con.createStatement();
				
					Vector<String> v_edit = new Vector<String>();
					con = dbconnect.getdbconnect();
					
					st = con.createStatement();
					psmt = con.prepareStatement("delete from diary where number = ?");
					
				
					int s = jt.getSelectedRow();
					String a1 = (String) jt.getValueAt(s, 0);

					psmt.setString(1, a1);
			
					int rs = psmt.executeUpdate();
					
					if(rs == 1) {
						JOptionPane.showMessageDialog(null, "삭제가 완료되었습니다.", "메시지", JOptionPane.QUESTION_MESSAGE);
						view();
					}
					

				} catch (SQLException e3) {
					e3.printStackTrace();
				}
			}
		});
		select.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view();
			}
		});
		
		add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new memo_add(a1, DB_id);
			}
		});
	
		edit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
					try {
						int s = jt.getSelectedRow();
						
						String a1 = (String) jt.getValueAt(s, 0);
						String a2 = (String) jt.getValueAt(s, 1);
						String a3 = (String) jt.getValueAt(s, 2);
						String a4 = (String) jt.getValueAt(s, 3);
						String a5 = (String) jt.getValueAt(s, 4);
						new memo_edit(a1,a2,a3,a4,a5);
						}
					
					catch(Exception e1) {
						JOptionPane.showMessageDialog(null, "테이블을 선택해주세요!", "메세지", JOptionPane.WARNING_MESSAGE);
						}
				}
			});
		
		cansel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		c.add(jps,BorderLayout.NORTH);
		c.add(p2,BorderLayout.CENTER);
		c.add(p1,BorderLayout.SOUTH);
		
		
		setSize(640, 640);
		setVisible(true);
	}
	
	private void view() {
		String sql = "select * from diary where petCode = "+ "'"+petCode+"';";
		try {
			rowData.clear();
			Connection con = dbconnect.getdbconnect();
			Statement stmt = con.createStatement();
			ResultSet  rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				Vector<String> v = new Vector<String>();
				v.add(rs.getString(1));
				v.add(rs.getString(2));
				v.add(rs.getString(3));
				v.add(rs.getString(4));
				v.add(rs.getString(5));

				rowData.add(v);
			}
			jt.updateUI();
		}catch(Exception ee) {System.out.println(ee);}
	}
}
