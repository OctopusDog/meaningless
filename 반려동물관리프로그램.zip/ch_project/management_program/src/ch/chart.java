package ch;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import setting.dbconnect;

public class chart extends JFrame{
	
	
	Color color[] = {Color.RED, Color.BLUE, Color.MAGENTA, Color.ORANGE, Color.BLACK};
	int drawAck[] = new int[6];
	
	Vector<String> result = new Vector<String>();
	Vector<String> label = new Vector<String>();
	
	JLabel jt[] = {new JLabel(), new JLabel(), new JLabel(), new JLabel(), new JLabel()};
	
	JPanel bottom = new JPanel();
	JPanel all = new JPanel();

	JPanel cc = new JPanel();
	
	JButton exit = new JButton("닫기");
	
	Connection con =null;
	PreparedStatement psmt = null;
	
	chart(){
		setTitle("통계");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		
		JLabel logo = new JLabel();
		
		Font font = new Font("맑은 고딕",Font.BOLD,25);
		Font font2 = new Font("굴림",Font.BOLD, 15);
	
		JPanel pp2 = new JPanel();
		pp2.setLayout(new FlowLayout(FlowLayout.RIGHT));
		pp2.add(logo);
		
		exit.setPreferredSize(new Dimension(150, 50));
		
		all.setLayout(new GridLayout(3,1));
		
		bottom.setLayout(new FlowLayout());
		cc.setLayout(new FlowLayout());
		cc.add(exit);
		
		exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		try {
			String sql = "select distinct classification from pet";
			con = dbconnect.getdbconnect();
			psmt = con.prepareStatement(sql);
			
			ResultSet rs = psmt.executeQuery();
			
			while(rs.next()) {
				label.add(rs.getString(1));
			}
		}
		
		catch(SQLException ee) {
			ee.printStackTrace();
		}
		
	for (int i = 0; i<label.size(); i++) {
		try {
			con = dbconnect.getdbconnect();
			psmt = con.prepareStatement("select count(*) from pet where classification = ?");
			
			String count = label.get(i);
			psmt.setString(1, count);
		
			
			ResultSet rs = psmt.executeQuery();
			
			while(rs.next()) {
				result.add(rs.getString(1));
				
				String a = label.get(i)+" : "+ result.get(i) + "개 / ";
				jt[i].setText(a);
				jt[i].setFont(font2);
				bottom.add(jt[i]);
			}
		} 
		
		catch (SQLException e1) {
			e1.printStackTrace();
		}
	}
	
		all.add(bottom);
		all.add(cc);
		all.add(pp2);
		
		c.add(new graph(),BorderLayout.CENTER);
		c.add(all,BorderLayout.SOUTH);
		
		
		setVisible(true);
		setSize(1200,800);
	}
	
	class graph extends JPanel{
		public void paint(Graphics g) {
			super.paintComponent(g);
			int sum = 0;
			
			Font font = new Font("맑은 고딕", Font.BOLD, 15);
			
			for(int i = 0; i<color.length;i++) {
				 sum = sum+Integer.parseInt(result.get(i));
			}
			
			for(int i = 0; i<color.length;i++) {
				drawAck[i] = (int)Math.round((Double.parseDouble(result.get(i))/(double)sum*360));
			}
			
			int s = 0;
			for(int i = 0; i<color.length; i++) {
				g.setFont(font);
				int k = Integer.parseInt(result.get(i));
				g.setColor(color[i]);
				g.drawString(label.get(i)+" "+Math.round(Integer.parseInt(result.get(i))*100/360)+"%", 150+i*150,20);
				
				g.fillArc(400, 100, 400, 400, s, drawAck[i]);
				s+=drawAck[i];
			}
		}
		
	}
	
	public static void main(String[] args) {	
		new chart();
	}

}
