package ch;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;

import setting.dbconnect;

public class main_form extends JFrame{
	
	JButton add, select, view, edit, delete, close;

	JLabel name, img, img2, img3,img4,img5;
	JTextField tf;
	
	JTable jt;
	
	JButton s_1, s_2, s_3, s_4;
	
	Vector<String> colData = new Vector<String>();
	Vector<Vector <String>>rowData = new Vector<Vector<String>>();
	
	JPanel p,p2,p3;
	
	Statement st =  null;
	Connection con = null;
	
	PreparedStatement psmt = null;
		
	main_form(String DB_id, String name2){
		
//		try {
//		    UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
//		} catch (Exception e) {
//		  e.printStackTrace();
//		}
	
		setTitle("main");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		colData.add("펫코드");
		colData.add("이름");
		colData.add("성별");
		colData.add("동물 종");
		colData.add("품 종");
		colData.add("생년월일");
		colData.add("담당의사");
		
		select = new JButton("조회");
		view = new JButton("전체보기");
		add = new JButton("추가");
		edit = new JButton("수정");
		delete = new JButton("삭제");
		close = new JButton("닫기");
		
		img = new JLabel(new ImageIcon("img/user.png"));
		
		img2 = new JLabel(new ImageIcon("img/first-aid-kit.png"));
		img3 = new JLabel(new ImageIcon("img/notepad.png"));
		img4 = new JLabel(new ImageIcon("img/jack-russell-terrier.png"));
		img5 = new JLabel(new ImageIcon("img/pie-chart.png"));

		
		name = new JLabel("성명");
		tf = new JTextField(10);
		
		jt = new JTable(rowData, colData);
		JScrollPane jps = new JScrollPane(jt);		
		p3 = new JPanel(new GridLayout(2,4));
		
		p3.add(img2);
		p3.add(img3);
		p3.add(img4);
		p3.add(img5);
		
		s_1 = new JButton("접종기록");
		s_2 = new JButton("의료차트");	
		s_3 = new JButton("프로필");
		s_4 = new JButton("종별현황");
			
		s_1.setFont(new Font("맑은 고딕", Font.BOLD, 15));
		s_2.setFont(new Font("맑은 고딕", Font.BOLD, 15));
		s_3.setFont(new Font("맑은 고딕", Font.BOLD, 15));
		s_4.setFont(new Font("맑은 고딕", Font.BOLD, 15));
		
		p3.add(s_1);
		p3.add(s_2);
		p3.add(s_3);
		p3.add(s_4);

		p = new JPanel();
		p.setLayout(new FlowLayout());
		
		p.add(img);
		p.add(name);
		p.add(tf);
		
		p.add(select);
		p.add(view);
		p.add(add);
		p.add(edit);
		p.add(delete);
		p.add(close);
		p.add(new JLabel("접속자 : "+DB_id+"("+name2+")"));
		
		view();
		
		s_1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				try {
					int s = jt.getSelectedRow();
					
					String a1 = (String) jt.getValueAt(s, 0);
					String a2 = (String) jt.getValueAt(s, 1);
					String a3 = (String) jt.getValueAt(s, 2);
					String a4 = (String) jt.getValueAt(s, 3);
					String a5 = (String) jt.getValueAt(s, 4);
					String a6 = (String) jt.getValueAt(s, 5);
					System.out.println(a1);
					new gungang_note(a1,a2,a3,a4,a5,a6);
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "테이블을 선택해주세요!", "메세지", JOptionPane.WARNING_MESSAGE);
				}
			
			}
		});
		
		s_2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				try {
					int s = jt.getSelectedRow();
					
					String a1 = (String) jt.getValueAt(s, 0);
					String a2 = (String) jt.getValueAt(s, 1);
					String a3 = (String) jt.getValueAt(s, 2);
					String a4 = (String) jt.getValueAt(s, 3);
					String a5 = (String) jt.getValueAt(s, 4);
					String a6 = (String) jt.getValueAt(s, 5);
					new memo(a1, DB_id);
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "테이블을 선택해주세요!", "메세지", JOptionPane.WARNING_MESSAGE);
				}
				
				
		
			}
		});
		
		s_3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				try {
					int s = jt.getSelectedRow();

					String a1 = (String) jt.getValueAt(s, 0);
					String a2 = (String) jt.getValueAt(s, 1);
					String a3 = (String) jt.getValueAt(s, 2);
					String a4 = (String) jt.getValueAt(s, 3);
					String a5 = (String) jt.getValueAt(s, 4);
					String a6 = (String) jt.getValueAt(s, 5);
					new sinche(a1,a2,a3,a4,a5,a6);
					
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "테이블을 선택해주세요!", "메세지", JOptionPane.WARNING_MESSAGE);
				}
				
				
			}
		});
		
		s_4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new chart();

			}
		});
		
		add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new main_add(DB_id);
			}
		});
		
		select.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				select();
			}
		});
		
		view.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view();
			}
		});
		
		delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
					delete();
					view();
			}
		});
		
		edit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {				
				int s = jt.getSelectedRow();
				
				String a1 = (String) jt.getValueAt(s, 0);
				String a2 = (String) jt.getValueAt(s, 1);
				String a3 = (String) jt.getValueAt(s, 2);
				String a4 = (String) jt.getValueAt(s, 3);
				String a5 = (String) jt.getValueAt(s, 4);
				String a6 = (String) jt.getValueAt(s, 5);
				new main_edit(a1,a2,a3,a4,a5,a6);
						
			}
		});
		
		close.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(null, "정말 종료하시겠습니까?", "경고", JOptionPane.OK_CANCEL_OPTION);		
				 if (result == 0) { //OK=0 , Cancel=2 리턴
                     System.exit(0);
                 }
			}
		});
		
		
		add(p, BorderLayout.NORTH);
		add(jps,BorderLayout.CENTER);
		add(p3,BorderLayout.SOUTH);
		
		setSize(900, 700);
		setVisible(true);
	}
			
	
	private void view() {
		String sql = "select * from pet";
		try {
			rowData.clear();
			Connection con = dbconnect.getdbconnect();
			Statement stmt = con.createStatement();
			ResultSet  rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				Vector<String> v = new Vector<String>();
				v.add(rs.getString(1));
				v.add(rs.getString(2));
				v.add(rs.getString(3));
				v.add(rs.getString(4));
				v.add(rs.getString(5));
				v.add(rs.getString(6));
				v.add(rs.getString(7));
				rowData.add(v);
			}
			jt.updateUI();
		}catch(Exception ee) {System.out.println(ee);}
	}
	
	
	private void select() {
		rowData.clear();
		String iname = tf.getText();
		String sql = "select * from pet where petName like'"+iname+"%'";
		try {	
		Connection con = dbconnect.getdbconnect();
		PreparedStatement psmt = con.prepareStatement(sql);
		
		
		ResultSet re = psmt.executeQuery(sql);
		
		while(re.next()) {
			Vector<String> v = new Vector<String>();
			v.add(re.getString(1));
			v.add(re.getString(2));
			v.add(re.getString(3));
			v.add(re.getString(4));
			v.add(re.getString(5));
			v.add(re.getString(6));
			v.add(re.getString(7));
			rowData.add(v);
		}
		jt.updateUI();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void delete(){	
		try {
			
			Connection con = dbconnect.getdbconnect();
			Statement stmt = con.createStatement();
		
			Vector<String> v_edit = new Vector<String>();
			con = dbconnect.getdbconnect();
			
			st = con.createStatement();
			psmt = con.prepareStatement("delete from pet where petCode = ?");
			
			
			int s = jt.getSelectedRow();
			String a1 = (String) jt.getValueAt(s, 1);

			psmt.setString(1, a1);
	
			int rs = psmt.executeUpdate();
			
			JOptionPane.showMessageDialog(null, "삭제가 완료되었습니다.", "메시지", JOptionPane.QUESTION_MESSAGE);
			

		} catch (SQLException e3) {
			e3.printStackTrace();
		}
	}
}
