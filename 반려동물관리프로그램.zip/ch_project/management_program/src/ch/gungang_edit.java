package ch;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import setting.dbconnect;

public class gungang_edit extends JFrame{
	JLabel c_00 ,c_01, c_02, c_03;
	JPanel p0,p1, p2, p3, p7;
	
	JTextField f0,f1, f2, f3;
	JButton c_add, c_exit;
	

	String db_01 = null;
	String db_02 = null;

	Statement st =  null;
	Connection con = null;
	
	PreparedStatement psmt = null;
	
	 gungang_edit(String a1, String a2, String a3, String a4){
		setTitle("수정");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new GridLayout(4, 2));
		
		c_01 = new JLabel("백신명:");
		c_02 = new JLabel("*최종일:");
		c_03 = new JLabel("예정일:");
		
		p1 = new JPanel(new GridLayout(1, 2));
		p2 = new JPanel(new GridLayout(1, 2));
		p3 = new JPanel(new GridLayout(1, 2));
		p7 = new JPanel();
		
		f1 = new JTextField(10);
		f2 = new JTextField(10);
		f3 = new JTextField(10);
		
		
		f1.setText(a2);
		f2.setText(a3);
		f3.setText(a4);
	
		
		c_add = new JButton("수정");
		c_exit = new JButton("닫기");
		
		c_add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					con = dbconnect.getdbconnect();
					st = con.createStatement();
					psmt = con.prepareStatement("update healthnote set vaccine = ?, lastdate = ?,  duedate = ? where number = ?");
					
					
					String db02 = f1.getText();
					String db03 = f2.getText();
					String db04 = f3.getText();
					
					System.out.println(db02+","+db03+","+db04+","+a4);
					psmt.setString(1, db02);
					psmt.setString(2, db03);
					psmt.setString(3, db04);
					psmt.setString(4, a1);
					
					int rs = psmt.executeUpdate();
					
					if(rs == 1) {
						JOptionPane.showMessageDialog(null, "수정이 완료되었습니다.", "메시지", JOptionPane.INFORMATION_MESSAGE);
					}
					
		
				} catch (SQLException e1) {
					JOptionPane.showMessageDialog(null, "오류!", "메시지", JOptionPane.ERROR_MESSAGE);
					e1.printStackTrace();
				}								
			}
		});
		
		c_exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				
			}
		});
		
		
		p1.add(c_01);
		p1.add(f1);
		
		p2.add(c_02);
		p2.add(f2);
		

		p3.add(c_03);
		p3.add(f3);
		
		
		p7.add(c_add);
		p7.add(c_exit);
		
		c.add(p1);
		c.add(p2);
		c.add(p3);
		c.add(p7);
		
		setSize(450, 250);
		setVisible(true);
	 }
}
