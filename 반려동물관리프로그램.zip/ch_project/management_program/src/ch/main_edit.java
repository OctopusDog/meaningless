package ch;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import setting.dbconnect;

public class main_edit extends JFrame{
	JLabel c_01, c_02, c_03 , c_04 , c_05 , c_06;
	JPanel p1, p2, p3, p4, p5, p6, p7;
	
	JTextField f1, f2, f3 ,f4 ,f5 ,f6;
	JButton c_add, c_exit;
	

	String db_01 = null;
	String db_02 = null;
	

	String db_code = null;
	String db_name = null;
	String db_gender = null;
	String db_classification = null;
	String db_breeds = null;
	String db_birth = null;
	
	Statement st =  null;
	Connection con = null;
	
	PreparedStatement psmt = null;
	
	main_edit(String a1, String a2, String a3, String a4, String a5, String a6){
		setTitle("동물정보 수정");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new GridLayout(7, 2));
	
				
		c_01 = new JLabel("등록번호:");
		c_02 = new JLabel("이름:");
		c_03 = new JLabel("성별:");
		c_04 = new JLabel("동물종:");
		c_05 = new JLabel("품종:");
		c_06 = new JLabel("생년월일:");
		
		p1 = new JPanel(new GridLayout(1, 2));
		p2 = new JPanel(new GridLayout(1, 2));
		p3 = new JPanel(new GridLayout(1, 2));
		p4 = new JPanel(new GridLayout(1, 2));
		p5 = new JPanel(new GridLayout(1, 2));
		p6 = new JPanel(new GridLayout(1, 2));
		p7 = new JPanel();
		
		f1 = new JTextField(10);
		f2 = new JTextField(10);
		f3 = new JTextField(10);
		f4 = new JTextField(10);
		f5 = new JTextField(10);
		f6 = new JTextField(10);
		

		f1.setText(a1);
		f1.enable(false);
		f2.setText(a2);
		f3.setText(a3);
		f4.setText(a4);
		f5.setText(a5);
		f6.setText(a6);
		
		
		c_add = new JButton("수정");
		c_exit = new JButton("닫기");
		
		c_add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					con = dbconnect.getdbconnect();
					st = con.createStatement();
					psmt = con.prepareStatement("update animal set name = ?, gender = ?, classification = ?, breeds = ?, birth = ? where code = ?");
					
					db_code = f1.getText();
					db_name = f2.getText();
					db_gender = f3.getText();
					db_classification = f4.getText();
					db_breeds = f5.getText();
					db_birth = f6.getText();
					
					
					psmt.setString(1, db_name);
					psmt.setString(2, db_gender);
					psmt.setString(3, db_classification);
					psmt.setString(4, db_breeds);
					psmt.setString(5, db_birth);
					psmt.setString(6, db_code);
					
					int rs = psmt.executeUpdate();
					JOptionPane.showMessageDialog(null, "고객 수정이 완료되었습니다.", "메시지", JOptionPane.INFORMATION_MESSAGE);
					
		
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		c_exit.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();		
			}
		});
		
			
		p1.add(c_01);
		p1.add(f1);
		
		p2.add(c_02);
		p2.add(f2);
		
		p3.add(c_03);
		p3.add(f3);
		
		p4.add(c_04);
		p4.add(f4);
		
		p5.add(c_05);
		p5.add(f5);
		
		p6.add(c_06);
		p6.add(f6);
		
		p7.add(c_add);
		p7.add(c_exit);
		
		c.add(p1);
		c.add(p2);
		c.add(p3);
		c.add(p4);
		c.add(p5);
		c.add(p6);
		c.add(p7);
		
		setSize(500, 400);
		setVisible(true);
	 	}
}
