package DB;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class insert_data {
	insert_data(){
		Statement st = null;
		Connection con =null;
		
		PreparedStatement psmt = null;
		
		String line = null;
		
		String tables [] = {"admin","contract","customer"};
		
		String insert_tables;
		Scanner read_file;
		
		String tmp = null;
		
		String admin_insert = "insert into admin values (?, ?, ?, ?, ?)";
		String contract_insert = "insert into contract values (?, ?, ?, ?, ?, ?)";
		String customer_insert = "insert into customer values (?, ?, ?, ?, ?, ?)";
		
		int i=0;
		int j=0;
		
		try {
				con = dbconnect.getdbconnect();
				st = con.createStatement();
				
				for(i = 0; i < tables.length; i++) {
					
					if(tables[i].equals("contract")) {
						tmp = contract_insert;					
					}
					
					if(tables[i].equals("admin")) {
						tmp = admin_insert;					
					}
					
					if(tables[i].equals("customer")) {
						tmp = customer_insert;					
					}
					
					read_file = new Scanner(new FileInputStream("D:\\customer\\customer\\Datafiles\\"+tables[i]+".txt"));
					line = read_file.nextLine();
					
					

					
						while(read_file.hasNext()) {	 
						String b [] = read_file.nextLine().split("\t");	
						psmt = con.prepareStatement(tmp);
							for(j=0;j<b.length;j++) {
								psmt.setString(j+1, b[j]);
							}	
							psmt.executeUpdate();
						}
				}
				System.out.println("insert data!");
		}
		
		catch(SQLException e) {
			System.out.println("SQL Err");
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			System.out.println("Not Found File");
		}
	}
}
