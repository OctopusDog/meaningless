package DB;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class create_table {
	create_table(){
		Statement st = null;
		Connection con =null;
		
		try {
			con = dbconnect.getdbconnect();
			st = con.createStatement();
				
			st.executeUpdate("create table admin(\r\n" + 
					"name varchar(20) not null,\r\n" + 
					"passwd varchar(20) not null,\r\n" + 
					"position varchar(20) null,\r\n" + 
					"jumin char(14) null,\r\n" + 
					"inputDate date null,\r\n" + 
					"primary key(name,passwd))");
			
			st.executeUpdate("create table contract(\r\n" + 
					"customerCode char(7) not null,\r\n" + 
					"contractName varchar(20) not null,\r\n" + 
					"regPrice int null,\r\n" + 
					"regDate date not null,\r\n" + 
					"monthPrice int null,\r\n" + 
					"adminName varchar(20) not null)");
			
			st.executeUpdate("create table customer(\r\n" + 
					"code char(7) not null,\r\n" + 
					"name varchar(20) not null,\r\n" + 
					"birth date null,\r\n" + 
					"tel varchar(20) null,\r\n" + 
					"address varchar(100) null,\r\n" + 
					"company varchar(20) null,\r\n" + 
					"primary key(code, name))");
			
			System.out.println("create table!");
		}
		
		catch(SQLException e) {
			System.out.println("Err");
		}	
	}
}
