package DB;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class create_database {
	create_database(){
		Statement st = null;
		Connection con =null;
		
		try {
			con = dbconnect.getdbconnect();
			st = con.createStatement();
			
			st.executeUpdate("create database is not exists customer");
			System.out.println("create database!");
			
		}catch(SQLException e) {
			e.getStackTrace();
		}		
	}
}
