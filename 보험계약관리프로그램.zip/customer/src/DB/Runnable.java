package DB;

import Form.Customer_main;

public class Runnable {

	public static void main(String[] args) {
//		new create_database();
//		new create_table();
		new insert_data();
	}

}
