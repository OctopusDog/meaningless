package Form;

import java.awt.Dimension;

import java.awt.Toolkit;

import javax.swing.UIManager;

import Test.Main;

public class Run_form {

	public static void main(String[] args) {
		

		
		try {
		    UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");					
			
		} catch (Exception e) {
		  e.printStackTrace();
		}

		new Customer_main().setLocationRelativeTo(null);
		

	}

}
