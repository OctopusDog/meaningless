package Form;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import DB.dbconnect;
import Test.Main;

public class chart extends JFrame{
	
	
	Color color[] = {Color.RED, Color.BLUE, Color.MAGENTA, Color.ORANGE, Color.BLACK, Color.PINK};
	int drawAck[] = new int[6];
	
	String result[] = new String[6];
	String label[] = {"종신보험", "변액연금보험", "연금보험", "의료실비보험", "무배당암보험", "여성건강보험"};
	
	JLabel jt[] = {new JLabel(), new JLabel(), new JLabel(), new JLabel(), new JLabel(), new JLabel()};
	
	JPanel bottom = new JPanel();
	JPanel all = new JPanel();

	
	JPanel cc = new JPanel();
	
	JButton exit = new JButton("종료");
	
	Statement st = null;
	Connection con =null;
	PreparedStatement psmt = null;
	chart(){
		setTitle("통계");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		
		ImageIcon img = new ImageIcon("images\\logo.png");
		
		JLabel logo = new JLabel(img);
		JLabel txt = new JLabel("LSH생활보험");
		
		Font font = new Font("맑은 고딕",Font.BOLD,25);
		Font font2 = new Font("굴림",Font.BOLD, 15);
		txt.setFont(font);
		
		JPanel pp2 = new JPanel();
		pp2.setLayout(new FlowLayout(FlowLayout.RIGHT));
		pp2.add(logo);
		pp2.add(txt);
		
		exit.setPreferredSize(new Dimension(150, 50));
		
		all.setLayout(new GridLayout(3,1));
		
		bottom.setLayout(new FlowLayout());
		cc.setLayout(new FlowLayout());
		cc.add(exit);
		
		exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				new insurance();
			}
		});
		
	for (int i = 0; i<label.length; i++) {
		try {
			con = dbconnect.getdbconnect();
			psmt = con.prepareStatement("select count(*) from contract where contractName = ?");
			
			String count = label[i];
			psmt.setString(1, count);
		
			
			ResultSet rs = psmt.executeQuery();
			
			while(rs.next()) {
				result[i] = rs.getString(1);
				
				String a = label[i]+" : "+ result[i] + "개 / ";
				jt[i].setText(a);
				jt[i].setFont(font2);
				bottom.add(jt[i]);
			}
		} 
		
		catch (SQLException e1) {
			e1.printStackTrace();
		}
	}
	
		all.add(bottom);
		all.add(cc);
		all.add(pp2);
		
		c.add(new graph(),BorderLayout.CENTER);
		c.add(all,BorderLayout.SOUTH);
		
		
		setVisible(true);
		setSize(1200,800);
	}
	
	class graph extends JPanel{
		public void paint(Graphics g) {
			super.paintComponent(g);
			int sum = 0;
			
			Font font = new Font("맑은 고딕", Font.BOLD, 15);
			
			for(int i = 0; i<color.length;i++) {
				 sum = sum+Integer.parseInt(result[i]);
			}
			
			for(int i = 0; i<color.length;i++) {
				drawAck[i] = (int)Math.round((Double.parseDouble(result[i])/(double)sum*360));
			}
			
			int s = 0;
			for(int i = 0; i<color.length; i++) {
				g.setFont(font);
				int k = Integer.parseInt(result[i]);
				g.setColor(color[i]);
				g.drawString(label[i]+" "+Math.round(Integer.parseInt(result[i])*100/360)+"%", 150+i*150,20);
				
				g.fillArc(400, 100, 400, 400, s, drawAck[i]);
				s+=drawAck[i];
			}
		}
		
	}

}
