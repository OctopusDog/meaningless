package Form;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import DB.dbconnect;

public class Customer_main extends JFrame{
	
	String DB_name;
	String DB_pw;
	
	JLabel logo;
	JLabel name;
	JLabel pw;
	JLabel logo2;
	
	JTextField name_tf;
	JPasswordField pw_tf;
	
	JButton check;
	JButton exit;
	
	JPanel p1,p2,p3,p4;
	
	Statement st = null;
	Connection con =null;
	
	PreparedStatement psmt = null;
	
	Customer_main(){
		setTitle("로그인");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new GridLayout(4, 1));
		
		this.setLocationRelativeTo(null);

		
		p1 = new JPanel();
		p2 = new JPanel();
		p3 = new JPanel();
		p4 = new JPanel();	
		
		ImageIcon img = new ImageIcon("images\\user.png");
		
		logo = new JLabel(img);
		
		
		logo2 = new JLabel("관리자 로그인");
		logo2.setFont(new Font("굴림",Font.CENTER_BASELINE, 20));
		
		name = new JLabel("이름        ");
		name_tf = new JTextField(10);
		
		pw = new JLabel("비밀번호");
		pw_tf = new JPasswordField(10);
		
		check = new JButton("확인");
		exit = new JButton("종료");

		check.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				try {
					con = dbconnect.getdbconnect();
					st = con.createStatement();
				
					psmt = con.prepareStatement("select name from admin Where name=? and passwd=?");
					
					DB_pw = new String(pw_tf.getPassword());
					DB_name = name_tf.getText();
					
					psmt.setString(1, DB_name);
					psmt.setString(2, DB_pw);
					
					ResultSet rs = psmt.executeQuery();
					
					if(rs.next()) {
						dispose();
						new insurance().setLocationRelativeTo(null);
					}
					
					else
					{
						JOptionPane.showMessageDialog(null,"아이디나 비밀번호를 확인해주세요!","오류", JOptionPane.ERROR_MESSAGE);
					}
					
					rs.close();
					psmt.close();
					con.close();
					
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		
		exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);					
			}
		});
		
		p1.add(logo);
		p1.add(logo2);
		
		p2.add(name);
		p2.add(name_tf);
		
		p3.add(pw);
		p3.add(pw_tf);
		
		p4.add(check);
		p4.add(exit);
		
		c.add(p1);
		c.add(p2);
		c.add(p3);
		c.add(p4);
		
		setVisible(true);
		setSize(300, 200);	
	}

}
