package Form;

import java.awt.BorderLayout;
import Test.Main;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class insurance extends JFrame{
	
	JPanel p1, p2;
	JButton c_add, c_lookup, c_management, c_exit, c_chart;
	JLabel img_Label;
	
	Font font = new Font("맑은 고딕",Font.BOLD,30);
	
	insurance(){
		setTitle("보험계약 관리화면");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		
		p1 = new JPanel();
		p2 = new JPanel();
		JPanel p3 = new JPanel();
		
		
			
		img_Label = new JLabel(new ImageIcon("images\\insurance.png"));
		JLabel text_Label = new JLabel("- LSH생활보험 -");
		text_Label.setFont(font);
		
		c_add = new JButton("고객등록");
		c_lookup = new JButton("고객조회");
		c_management = new JButton("계약 관리");
		c_chart = new JButton("통계");
		c_exit = new JButton("종료");
				
		
		c_management.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new management().setLocationRelativeTo(null);
				dispose();
			}
		});
		
		c_exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);			
			}
		});
		
		c_add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new customer_join().setLocationRelativeTo(null);	
		
			}
		});
		
		c_lookup.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new lookup().setLocationRelativeTo(null);
				dispose();
				
			}
		});
		
		c_chart.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new Main().setLocationRelativeTo(null);
			}
		});
		
		p1.add(c_add);
		p1.add(c_lookup);
		p1.add(c_management);
		p1.add(c_chart);
		p1.add(c_exit);
		
		p2.add(img_Label);
		
		p3.add(text_Label);
		
		c.add(p1,BorderLayout.NORTH );
		c.add(p2,BorderLayout.CENTER);
		c.add(p3,BorderLayout.SOUTH);
		
		setSize(600, 400);
		setVisible(true);
	}
	
	}
