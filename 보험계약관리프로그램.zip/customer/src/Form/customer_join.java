package Form;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import DB.dbconnect;

public class customer_join extends JFrame{
	JLabel c_code, c_name, c_birth, c_tel, c_addr, c_company;
	JPanel p1, p2, p3, p4, p5, p6, p7;
	JPanel p1_1;
	
	JTextField f1, f2, f3, f4, f5, f6;
	JButton c_add, c_exit;
	

	String db_code = null;
	String db_name = null;
	String db_birth = null;
	String db_tel = null;
	String db_addr = null;
	String db_company = null;
	
	Statement st =  null;
	Connection con = null;
	
	PreparedStatement psmt = null;
	
	customer_join(){
		setTitle("고객 등록");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new GridLayout(7, 2));
				
		c_code = new JLabel("고객 코드");
		c_name = new JLabel("*고객 명:");
		c_birth = new JLabel("*생년월일(YYYY-MM-DD):");
		c_tel = new JLabel("*연 락 처:");
		c_addr = new JLabel("주소");
		c_company = new JLabel("회 사");
		
		
		p1 = new JPanel(new GridLayout(1, 2));
		p2 = new JPanel(new GridLayout(1, 2));
		p3 = new JPanel(new GridLayout(1, 2));
		p4 = new JPanel(new GridLayout(1, 2));
		p5 = new JPanel(new GridLayout(1, 2));
		p6 = new JPanel(new GridLayout(1, 2));
		p7 = new JPanel();
		
		f1 = new JTextField(10);
		f1.setEnabled(false);
		f2 = new JTextField(10);
		f3 = new JTextField(10);
		f4 = new JTextField(10);
		f5 = new JTextField(10);
		f6 = new JTextField(10);
		
		f3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					Calendar cal = Calendar.getInstance();
					int year = cal.get(Calendar.YEAR)-2000;
					String str[] = f3.getText().split("-");
					int hap = Integer.valueOf(str[0])+Integer.valueOf(str[1])+Integer.valueOf(str[2]);
					f1.setText("S"+year+hap);
				}
				
				catch(Exception err) {
					JOptionPane.showMessageDialog(null, "생년월일을 YYYY-MM-DD 형식으로 입력해주세요!", "Err", JOptionPane.ERROR_MESSAGE);
					
				}
			
			}
		});
		
		
		
		c_add = new JButton("추가");
		c_exit = new JButton("닫기");
		
		c_exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				
			}
		});
		
		c_add.addActionListener(new ActionListener() {		
			@Override
			public void actionPerformed(ActionEvent e) {
				if(f2.getText().equals("") || f3.getText().equals("") || f4.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "필수 항목(*)을 모두 입력하세요", "고객 등록 에러", JOptionPane.ERROR_MESSAGE);
				}
				
				
				try {
					
					con = dbconnect.getdbconnect();
					st = con.createStatement();
						
					psmt = con.prepareStatement("insert into customer values(?, ?, ?, ?, ?, ?)");
					
					db_code = f1.getText();
					db_name = f2.getText();
					db_birth = f3.getText();
					db_tel = f4.getText();
					db_addr = f5.getText();
					db_company = f6.getText();
						
					psmt.setString(1, db_code);
					psmt.setString(2, db_name);
					psmt.setString(3, db_birth);
					psmt.setString(4, db_tel);
					psmt.setString(5, db_addr);
					psmt.setString(6, db_company);
					
					int rs = psmt.executeUpdate();
					if(rs == 1){
						JOptionPane.showMessageDialog(null, "고객 추가가 완료되었습니다.", "메시지", JOptionPane.INFORMATION_MESSAGE);
						}
					
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
				
				
			 
				
			}	
		});
		
		p1.add(c_code);
		p1.add(f1);
		
		p2.add(c_name);
		p2.add(f2);
		
		p3.add(c_birth);
		p3.add(f3);
		
		p4.add(c_tel);
		p4.add(f4);
		
		p5.add(c_addr); 
		p5.add(f5);
		
		p6.add(c_company);
		p6.add(f6);
		
		p7.add(c_add);
		p7.add(c_exit);
		
		c.add(p1);
		c.add(p2);
		c.add(p3);
		c.add(p4);
		c.add(p5);
		c.add(p6);
		c.add(p7);
		setSize(500, 400);
		setVisible(true);
	}
	}

