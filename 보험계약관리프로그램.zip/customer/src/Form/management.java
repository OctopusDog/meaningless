package Form;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import DB.dbconnect;

public class management extends JFrame{
	
	JLabel c_code, c_name, c_birth, c_tel, c_gift, join_cash, month_cash, admin, content;
	
	JTable jt;
	
	Vector<String> colData = new Vector<String>();
	Vector<Vector <String>>rowData = new Vector<Vector<String>>();
	
	JComboBox box_name = new JComboBox();
	JComboBox box_admin = new JComboBox();
	JComboBox box_gift= new JComboBox();
	
	JTextField f1,f2,f3,f4,f5;
	
	JPanel p1, left, right,p2 ,p3, p4 ,pp;
	
	Statement st =  null;
	Connection con = null;
	
	PreparedStatement psmt = null;
	
	JButton add,delete,save,close;
	
	management(){
		
		setTitle("보험 계약");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		
		JFrame window = new JFrame();
				
		c_code = new JLabel("고객코드:");
		c_gift = new JLabel("상품명:");
		c_name = new JLabel("고객명:");
		join_cash = new JLabel("가입금액:");
		c_birth = new JLabel("생년월일:");
		c_tel = new JLabel("전화번호");
		month_cash = new JLabel("월보험료:");
		admin = new JLabel("담당자:");
		content = new JLabel("<고객 보험 계약 현황>");
		
		add = new JButton("가입");
		delete = new JButton("삭제");
		save = new JButton("파일로저장");
		close = new JButton("닫기");
		
		f1 = new JTextField(10);
		f2 = new JTextField(10);
		f3 = new JTextField(10);
		f4 = new JTextField(10);
		f5 = new JTextField(10);
		
		p1 = new JPanel(new GridLayout(1, 2));
		p2 = new JPanel();
		p3 = new JPanel();
		pp = new JPanel(new GridLayout(3,0));
		p4 = new JPanel();
		left = new JPanel(new GridLayout(4,2));
		right = new JPanel(new GridLayout(3,2));
		
		colData.add("customerCode");
		colData.add("contractName");
		colData.add("regPrice");
		colData.add("regDate");
		colData.add("monthPrice");
		colData.add("adminName");
		
		
		jt = new JTable(rowData, colData);
		JScrollPane jps = new JScrollPane(jt);
		
		ImageIcon img = new ImageIcon("images\\logo.png");
		
		JLabel logo = new JLabel(img);
		JLabel txt = new JLabel("LSH생활보험");
		
		Font font = new Font("맑은 고딕",Font.BOLD,25);
		txt.setFont(font);
		
		JPanel pp2 = new JPanel();
		pp2.setLayout(new FlowLayout(FlowLayout.RIGHT));
		pp2.add(logo);
		pp2.add(txt);
		
		delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				delete();
			}
		});
		

		
		add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					
					String sql = "insert into contract values(?,?,?,?,?,?)";
					con = dbconnect.getdbconnect();
					st = con.createStatement();
				
					psmt = con.prepareStatement(sql);
					
					SimpleDateFormat format1 = new SimpleDateFormat ( "yyyy-MM-dd");
					
					String ct_code = f1.getText();
					String ct_contract = box_gift.getSelectedItem().toString();
					String ct_regPrice = f4.getText();
					String ct_regDate = format1.format (System.currentTimeMillis());;
					String ct_regMonth = f5.getText();
					String ct_adminName = box_admin.getSelectedItem().toString();
					
						
					psmt.setString(1, ct_code);
					psmt.setString(2, ct_contract);
					psmt.setString(3, ct_regPrice);
					psmt.setString(4, ct_regDate);
					psmt.setString(5, ct_regMonth);
					psmt.setString(6, ct_adminName);
					
					psmt.executeUpdate();

					JOptionPane.showMessageDialog(null, "보험 가입이 완료 되었습니다!","환영합니다",JOptionPane.INFORMATION_MESSAGE);
					f4.setText("");
					f5.setText("");
				
					psmt.close();
					con.close();
					
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		close.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				new insurance().setLocationRelativeTo(null);
				
			}
		});
		
		String sql = "select customerCode, contractName, regPrice, regDate, monthPrice, adminName\r\n" + 
				"from contract, customer\r\n" + 
				"where contract.customerCode = customer.code AND customer.name = '이혜신';";
		try {
			rowData.clear();
			Connection con = dbconnect.getdbconnect();
			Statement stmt = con.createStatement();
			ResultSet  rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				Vector<String> v = new Vector<String>();
				v.add(rs.getString(1));
				v.add(rs.getString(2));
				v.add(rs.getString(3));
				v.add(rs.getString(4));
				v.add(rs.getString(5));
				v.add(rs.getString(6));
				rowData.add(v);
			}
			jt.updateUI();
		}catch(Exception ee) {System.out.println(ee);}
		
		
		try {
			con = dbconnect.getdbconnect();
			st = con.createStatement();
			
			ResultSet re = st.executeQuery("select name from customer");
			
			while(re.next()) {
				String name = re.getString("name");
				box_name.addItem(name);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		try {
			con = dbconnect.getdbconnect();
			st = con.createStatement();
			
			ResultSet re = st.executeQuery("select adminName from contract");
			
			while(re.next()) {
				String name = re.getString("adminName");
				box_admin.addItem(name);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		try {
			con = dbconnect.getdbconnect();
			st = con.createStatement();
			
			ResultSet re = st.executeQuery("select distinct contractName from contract ");
			while(re.next()) {
				String name = re.getString("contractName");
				box_gift.addItem(name);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	
		
		try {
			
			con =dbconnect.getdbconnect();
			st = con.createStatement();
			
			String customerName = box_name.getSelectedItem().toString();
			ResultSet re = st.executeQuery("select code, birth, tel from customer where name = '"+customerName+"'");
	
			while(re.next()) {
				f1.setText(re.getString(1));
				f2.setText(re.getString(2));
				f3.setText(re.getString(3));
			
				}
			}	
			catch(Exception e2) {
				e2.printStackTrace();
		}
		
		
		
		box_name.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					
					con =dbconnect.getdbconnect();
					st = con.createStatement();
					
					String customerName = box_name.getSelectedItem().toString();
					ResultSet re = st.executeQuery("select code, birth, tel from customer where name = '"+customerName+"'");
			
					while(re.next()) {
						f1.setText(re.getString(1));
						f2.setText(re.getString(2));
						f3.setText(re.getString(3));
					
						}
					}	
					catch(Exception e2) {
						e2.printStackTrace();
				}
				
			}
		});
		
		save.addActionListener(new ActionListener() {
			

			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser jf = new JFileChooser();
				
				int returnVal = jf.showSaveDialog(window);
				
				if(returnVal == jf.APPROVE_OPTION) {
					 File selectedFile = jf.getSelectedFile();
			         System.out.println(selectedFile);
			         
			         try{
			             // 파일 객체 생성
			        	 File file = new File(selectedFile.toString());
			              
			             // true 지정시 파일의 기존 내용에 이어서 작성
			             FileWriter fw = new FileWriter(file, true) ;
			              
			             // 파일안에 문자열 쓰기
			             fw.write("고객명 : "+"("+f1.getText()+")\r\n\r\n");
			             fw.write("");
			             fw.write("담당자명 : "+"("+box_name.getSelectedItem().toString()+")\r\n");
			             fw.write("보험상품\t\t\t\t"+"가입금액\t\t\t\t"+"가입일\t\t\t\t"+"월보험료\t\t\t\t");
			             fw.flush();
			             
			         	con =dbconnect.getdbconnect();
						st = con.createStatement();
						
						String m_code = f1.getText();
						ResultSet re = st.executeQuery("select contractName, regPrice, regDate, monthPrice from  contract where customerCode = '"+m_code+"'");
				
						while(re.next()) {
							fw.write("\r\n"+re.getString(1)+"\t\t\t\t");
							fw.write(re.getString(2)+"\t\t\t\t");
							fw.write(re.getString(3)+"\t\t\t\t");
							fw.write(re.getString(4)+"\t\t\t\t");	
							fw.flush();
						
						}
			  
			             // 객체 닫기
			             fw.close();
			              
			              
			         }catch(Exception e2){
			             e2.printStackTrace();
			         }      
				}
				
				
				
			}
		});
		
		box_name.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				rowData.clear();
				String iname = box_name.getSelectedItem().toString();
				
				String sql = "select customerCode, contractName, regPrice, regDate, monthPrice, adminName\r\n" + 
						"from contract, customer\r\n" + 
						"where contract.customerCode = customer.code AND customer.name = '"+iname+"'";
				
				
				try {	
				Connection con = dbconnect.getdbconnect();
				PreparedStatement psmt = con.prepareStatement(sql);
				
				ResultSet re = psmt.executeQuery(sql);
				
				while(re.next()) {
					Vector<String> v = new Vector<String>();
					v.add(re.getString(1));
					v.add(re.getString(2));
					v.add(re.getString(3));
					v.add(re.getString(4));
					v.add(re.getString(5));
					v.add(re.getString(6));
					rowData.add(v);
				}
				jt.updateUI();
				
				}catch (Exception ee) {
					ee.printStackTrace();
				}
			}
		});
			
		left.add(c_code);
		left.add(f1);
		
		left.add(c_name);
		left.add(box_name);
		
		left.add(c_birth);
		left.add(f2);
		
		left.add(c_tel);
		left.add(f3);
		
		right.add(c_gift);
		right.add(box_gift);
		
		right.add(join_cash);
		right.add(f4);
		
		right.add(month_cash);
		right.add(f5);
		
		p1.add(left);
		p1.add(right);
		
		p2.add(admin);
		p2.add(box_admin);
		p2.add(add);
		p2.add(delete);
		p2.add(save);
		p2.add(close);
	
		p3.add(content);
		
		pp.add(p1);
		pp.add(p2);
		pp.add(p3);
		c.add(pp,BorderLayout.NORTH);
		c.add(jps,BorderLayout.CENTER);
		c.add(pp2,BorderLayout.SOUTH);
		
		setSize(700, 800);
		setVisible(true);
	}
	
	private void delete(){	
	try {
	
		Vector<String> v_edit = new Vector<String>();
		con = dbconnect.getdbconnect();
		st = con.createStatement();
		psmt = con.prepareStatement("delete from contract where customerCode = ? AND contractName = ?");
		
		
		int s = jt.getSelectedRow();
		String a1 = (String) jt.getValueAt(s, 0);
		System.out.println(a1);
		
		
		int k = jt.getSelectedRow();
		String a2 = (String) jt.getValueAt(k, 1);
		System.out.println(a2);

		psmt.setString(1, a1);
		psmt.setString(2, a2);
		
		int rs = psmt.executeUpdate();
		
		JOptionPane.showMessageDialog(null, "삭제가 완료되었습니다.", "메시지", JOptionPane.QUESTION_MESSAGE);
		

	} catch (SQLException e1) {
		e1.printStackTrace();
	}
}
	
	
}
