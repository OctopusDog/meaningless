package Form;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import DB.dbconnect;

public class lookup extends JFrame{
	JButton select, view, edit, delete, close;
	
	
	Statement st =  null;
	Connection con = null;
	
	PreparedStatement psmt = null;
	
	JLabel name;
	JTextField tf;
	
	JTable jt;
	
	Vector<String> colData = new Vector<String>();
	Vector<Vector <String>>rowData = new Vector<Vector<String>>();
	
	JPanel p;
	JPanel pp;
	
	lookup(){
		setTitle("고객조회");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
		colData.add("cde");
		colData.add("name");
		colData.add("birth");
		colData.add("tel");
		colData.add("address");
		colData.add("company");
		
		select = new JButton("조회");
		view = new JButton("전체보기");
		edit = new JButton("수정");
		delete = new JButton("삭제");
		close = new JButton("닫기");
		
		name = new JLabel("성명");
		tf = new JTextField(10);
		
		jt = new JTable(rowData, colData);
		JScrollPane jps = new JScrollPane(jt);
		
		p = new JPanel();
		p.setLayout(new FlowLayout());
		
		p.add(name);
		p.add(tf);
		
		p.add(select);
		p.add(view);
		p.add(edit);
		p.add(delete);
		p.add(close);
		
		ImageIcon img = new ImageIcon("images\\logo.png");
		
		JLabel logo = new JLabel(img);
		JLabel txt = new JLabel("LSH생활보험");
		
		Font font = new Font("맑은 고딕",Font.BOLD,25);
		txt.setFont(font);
		
		pp = new JPanel();
		pp.setLayout(new FlowLayout(FlowLayout.RIGHT));
		pp.add(logo);
		pp.add(txt);
		
		delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					delete();
				}
				
				catch(Exception eee) {
					JOptionPane.showMessageDialog(null, "삭제 할 가입자를 선택해주세요.", "Err", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		
		
		close.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();		
				new insurance().setLocationRelativeTo(null);
			}
		});
		
		select.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				select();
			}
		});
		
		view.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view();
			}
		});
		
		edit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Vector<String> v_edit = new Vector<String>();
				int s = jt.getSelectedRow();
				//v_edit.add(s);
				
				String a1 = (String) jt.getValueAt(s, 0);
				String a2 = (String) jt.getValueAt(s, 1);
				String a3 = (String) jt.getValueAt(s, 2);
				String a4 = (String) jt.getValueAt(s, 3);
				String a5 = (String) jt.getValueAt(s, 4);
				String a6 = (String) jt.getValueAt(s, 5);
							
				new edit(a1,a2,a3,a4,a5,a6);				
			}
		});
		
		add(p, BorderLayout.NORTH);
		add(jps, BorderLayout.CENTER);
		add(pp, BorderLayout.SOUTH);
		
		setSize(900, 600);
		setVisible(true);
	}
			
	
		private void delete(){	
		try {
		
			Vector<String> v_edit = new Vector<String>();
			con = dbconnect.getdbconnect();
			st = con.createStatement();
			psmt = con.prepareStatement("delete from customer where code = ?");
			
			
			int s = jt.getSelectedRow();
			String a1 = (String) jt.getValueAt(s, 0);
			System.out.println(a1);

			psmt.setString(1, a1);
	
			int rs = psmt.executeUpdate();
			
			JOptionPane.showMessageDialog(null, "삭제가 완료되었습니다.", "메시지", JOptionPane.INFORMATION_MESSAGE);
			view();

		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	}
	
	private void view() {
		String sql = "select * from customer";
		try {
			rowData.clear();
			Connection con = dbconnect.getdbconnect();
			Statement stmt = con.createStatement();
			ResultSet  rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				Vector<String> v = new Vector<String>();
				v.add(rs.getString(1));
				v.add(rs.getString(2));
				v.add(rs.getString(3));
				v.add(rs.getString(4));
				v.add(rs.getString(5));
				v.add(rs.getString(6));
				rowData.add(v);
			}
			jt.updateUI();
		}catch(Exception ee) {System.out.println(ee);}
	}
	
	
	private void select() {
		rowData.clear();
		String iname = tf.getText();
		System.out.println(iname);
		String sql = "select * from customer where name like'"+iname+"%'";
		try {	
		Connection con = dbconnect.getdbconnect();
		PreparedStatement psmt = con.prepareStatement(sql);
		
		
		ResultSet re = psmt.executeQuery(sql);
		
		while(re.next()) {
			Vector<String> v = new Vector<String>();
			v.add(re.getString(1));
			v.add(re.getString(2));
			v.add(re.getString(3));
			v.add(re.getString(4));
			v.add(re.getString(5));
			v.add(re.getString(6));
			rowData.add(v);
		}
		jt.updateUI();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
}

