package Test;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import com.teamdev.jxbrowser.chromium.Browser;
import com.teamdev.jxbrowser.chromium.events.FinishLoadingEvent;
import com.teamdev.jxbrowser.chromium.events.LoadAdapter;
import com.teamdev.jxbrowser.chromium.swing.BrowserView;

import DB.dbconnect;


public class Main extends JFrame{
	
	String label[] = {"종신보험", "변액연금보험", "연금보험", "의료실비보험", "무배당암보험", "여성건강보험"};
	Vector<Integer> vc = new Vector<Integer>();
	
	private Browser browser = new Browser();
	private BrowserView browserView = new BrowserView(browser); 	
	
	Connection con =null;
	PreparedStatement psmt = null;
	
		 public Main() {
			 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			 setTitle("Google Chart");
			 setVisible(true);
			 setResizable(false);
			 setSize(1200,700);
			 
			 Container c = getContentPane();
			 c.setLayout(new BorderLayout());
			 
			 this.setLocationRelativeTo(null);
			 			 
			 JButton close = new JButton("닫기");

			 close.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			 
			 browser.addLoadListener(new LoadAdapter() {
				 public void onFinishLoadingFrame(FinishLoadingEvent event) {
					 if(event.isMainFrame()) {
						 System.out.println("Load OK!");
					 }
				 }
				 
			});
			 
			 Font font = new Font("맑은 고딕",Font.CENTER_BASELINE , 15);
			 close.setFont(font);

			 JPanel p_north = new JPanel();
			 p_north.setLayout(new FlowLayout());
			 p_north.add(close);
			 p_north.setBackground(Color.WHITE);
			 
			 String title = "<보험 상품 가입자 현황 통계 >";
			 ArrayList<PieElement> list = new ArrayList<PieElement>();
			 
				for (int i = 0; i<label.length; i++) {
					try {
						con = dbconnect.getdbconnect();
						psmt = con.prepareStatement("select count(*) from contract where contractName = ?");
						
						String count = label[i];
						psmt.setString(1, count);
					
						
						ResultSet rs = psmt.executeQuery();
						
						while(rs.next()) {
							
							int a = rs.getInt(1);
							vc.add(a);
					
						}
						
	
					} 
					
					catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
				
				
				String bb;
				
				for(int i = 0; i<label.length; i++) {	
					 
					 bb = label[i];
					 int num = vc.get(i);
					 list.add(new PieElement(bb, num));	
				}
			 
				 browser.loadHTML(new GoogleAPI().getPieChart(title, list));
				 c.add(p_north, BorderLayout.SOUTH);
				 c.add(browserView, BorderLayout.CENTER);
				 c.revalidate();
			
	 
		 }
}
