package Test;

public class Execute {

	public static void main(String[] args) {
		Main main = new Main();
		
	}

}
