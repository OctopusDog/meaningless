package meal;

import java.sql.Connection;
import java.sql.Statement;

public class create_table {
	
	Statement st = null;
	Connection con = null ;
	
	create_table(){
		try {
			con = dbconnect.getdbconnect();
			st = con.createStatement();
			
			//member table
			st.executeUpdate("create table if not exists member(\r\n" + 
					"	memberNo int not null auto_increment,\r\n" + 
					"	memberName varchar(20) null,\r\n" + 
					"	passwd varchar(4) null,\r\n" + 
					"	primary key(memberNo)\r\n" + 
					")");
			
			//cuisine table
			st.executeUpdate("create table if not exists cuisine(\r\n" + 
					"	cuisineNo int not null auto_increment,\r\n" + 
					"	cuisineName varchar(10) null,\r\n" + 
					"	primary key(cuisineNo)\r\n" + 
					")");
		
			//meal table
			st.executeUpdate("create table if not exists meal(\r\n" + 
					"	mealNo int not null auto_increment,\r\n" + 
					"	cuisineNo int null,\r\n" + 
					"	mealName varchar(20) null,\r\n" + 
					"	price int null,\r\n" + 
					"	maxCount int null,\r\n" + 
					"	todayMeal tinyint(1) null,\r\n" + 
					"	primary key(mealNo)\r\n" + 
					")");
			
			//orderlist table
			st.executeUpdate("create table if not exists orderlist(\r\n" + 
					"	orderNo int not null auto_increment,\r\n" + 
					"	cuisineNo int null,\r\n" + 
					"	mealNo int null,\r\n" + 
					"	memberNo int null,\r\n" + 
					"	ordereCount int null,\r\n" + 
					"	amount int null,\r\n" + 
					"	orderDate datetime null,\r\n" + 
					"	primary key(orderNo)\r\n" + 
					")");
			
			System.out.println("Create table OK.");
		}catch(Exception e) {
			System.out.println("Err");
		}
	}
}
