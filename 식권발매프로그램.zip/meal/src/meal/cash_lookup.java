package meal;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class cash_lookup extends JFrame{
	
	JPanel p1, p2;
	JButton search, all_view, print, exit;
	String menu;
	
	JTextField tf1 = new JTextField(10);
	
	JLabel kind = new JLabel("메뉴명:");
	
	Statement st =  null;
	Connection con = null;
	
	PreparedStatement psmt = null;
	
	
	Vector<String> colData = new Vector<String>();
	Vector<Vector <String>>rowData = new Vector<Vector<String>>();
	
	JTable jt;
	
	JFrame window = new JFrame();
	
	cash_lookup(){
		setTitle("메뉴 관리");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setSize(800, 800);
		
		colData.add("종류");
		colData.add("메뉴명");
		colData.add("사원명");
		colData.add("결제수량");
		colData.add("총결제금액");
		colData.add("결제일");
		
		Container c = getContentPane();
	
		jt = new JTable(rowData, colData);
		JScrollPane jps = new JScrollPane(jt);
	
		search = new JButton("조회");
		all_view = new JButton("모두보기");
		print = new JButton("인쇄");
		exit = new JButton("닫기");
		
		p1 = new JPanel();
		p2 = new JPanel();
		p2.setLayout(new GridLayout(1, 1));
		
		p1.add(kind);
		p1.add(tf1);
		p1.add(search);
		p1.add(all_view);
		p1.add(print);
		p1.add(exit);
		
		p2.add(jps);
		
		c.add(p1,BorderLayout.NORTH );
		c.add(p2,BorderLayout.CENTER);
		
	    
        int row = jt.getRowCount();
        int column = jt.getColumnCount();
        
       
		
		String sql = "select  o.cuisineNo, m1.mealName, m.memberName, o.ordereCount, o.amount, o.orderDate\r\n" + 
				"from orderlist o, meal m1, member m\r\n" + 
				"where o.mealNo = m1.mealNo AND m.memberNo = o.memberNo;";
		
		try {
			rowData.clear();
			Connection con = dbconnect.getdbconnect();
			Statement stmt = con.createStatement();
			ResultSet  rs = stmt.executeQuery(sql);
			
			
			
			while(rs.next()) {
				Vector<String> v = new Vector<String>();
				if(rs.getString(1).equals("1")) {
					menu = "한식";
					v.add(menu);
				}
				
				else if(rs.getString(1).equals("2")){
					menu = "중식";
					v.add(menu);

				}
				
				else if(rs.getString(1).equals("3")){
					menu = "일식";
					v.add(menu);

				}
				
				else if(rs.getString(1).equals("4")){
					menu = "양식";
					v.add(menu);

				}
				v.add(rs.getString(2));
				v.add(rs.getString(3));
				v.add(rs.getString(4));
				v.add(rs.getString(5));
				v.add(rs.getString(6));
				rowData.add(v);
			}
			
			jt.updateUI();
		
		}
		
		catch(SQLException e1) {
			e1.printStackTrace();
		}
		
		print.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser jf = new JFileChooser();
				
				int returnVal = jf.showSaveDialog(window);
				
				if(returnVal == jf.APPROVE_OPTION) {
					 File selectedFile = jf.getSelectedFile();
			         System.out.println(selectedFile);
			         
			         try{
			             
			             // 파일 객체 생성
			        	 File file = new File(selectedFile.toString());
			              
			             // true 지정시 파일의 기존 내용에 이어서 작성
			             FileWriter fw = new FileWriter(file, true) ;
			              
			             // 파일안에 문자열 쓰기
			             fw.write("종류\t\t"+"메뉴명\t\t"+"\t사원명\t\t"+"결제수량\t\t"+"총결제금액\t\t"+"결제일\t\t");
			             fw.write("\r\n");
			             
			             int row = jt.getRowCount();
			             int column = jt.getColumnCount();
			             
			             for (int j = 0; j  < row; j++) {
			                 for (int i = 0; i  < column; i++) {
			                	fw.write(jt.getValueAt(j, i).toString()+"\t\t");
			                 }
			                 fw.write("\r\n");
			             }
			             
			             fw.flush();
			  
			             // 객체 닫기
			             fw.close();
			              
			              
			         }
			         
			         catch(Exception e2){
			             e2.printStackTrace();
			         }      		
				}
			}
		});
		
		search.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String getMenu = tf1.getText();
				String sql = "select  o.cuisineNo, m1.mealName, m.memberName, o.ordereCount, o.amount, o.orderDate\r\n" + 
						"from orderlist o, meal m1, member m\r\n" + 
						"where o.mealNo = m1.mealNo AND m.memberNo = o.memberNo AND m1.mealName like '%"+getMenu+"%'";
				
				try {
					rowData.clear();
					Connection con = dbconnect.getdbconnect();
					Statement stmt = con.createStatement();
					ResultSet  rs = stmt.executeQuery(sql);
					
					while(rs.next()) {
						Vector<String> v = new Vector<String>();
						if(rs.getString(1).equals("1")) {
							menu = "한식";
							v.add(menu);
						}
						
						else if(rs.getString(1).equals("2")){
							menu = "중식";
							v.add(menu);

						}
						
						else if(rs.getString(1).equals("3")){
							menu = "일식";
							v.add(menu);

						}
						
						else if(rs.getString(1).equals("4")){
							menu = "양식";
							v.add(menu);

						}
						v.add(rs.getString(2));
						v.add(rs.getString(3));
						v.add(rs.getString(4));
						v.add(rs.getString(5));
						v.add(rs.getString(6));
						rowData.add(v);
					}
					
					jt.updateUI();
				
				}
				
				catch(SQLException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		
		all_view.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String sql = "select  o.cuisineNo, m1.mealName, m.memberName, o.ordereCount, o.amount, o.orderDate\r\n" + 
						"from orderlist o, meal m1, member m\r\n" + 
						"where o.mealNo = m1.mealNo AND m.memberNo = o.memberNo;";
				
				try {
					rowData.clear();
					Connection con = dbconnect.getdbconnect();
					Statement stmt = con.createStatement();
					ResultSet  rs = stmt.executeQuery(sql);
					
					while(rs.next()) {
						Vector<String> v = new Vector<String>();
						if(rs.getString(1).equals("1")) {
							menu = "한식";
							v.add(menu);
						}
						
						else if(rs.getString(1).equals("2")){
							menu = "중식";
							v.add(menu);

						}
						
						else if(rs.getString(1).equals("3")){
							menu = "일식";
							v.add(menu);

						}
						
						else if(rs.getString(1).equals("4")){
							menu = "양식";
							v.add(menu);

						}
						v.add(rs.getString(2));
						v.add(rs.getString(3));
						v.add(rs.getString(4));
						v.add(rs.getString(5));
						v.add(rs.getString(6));
						rowData.add(v);
					}
					
					jt.updateUI();
				
				}
				
				catch(SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
	}
}
