package meal;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Payment extends JFrame{
	
	JLabel memberNo, passwd;
	
	JButton yes, no;
	JComboBox memberNo_box = new JComboBox();
	
	JTextField tf1;
	
	Statement st = null;
	Connection con =null;	
	PreparedStatement psmt = null;
	
	JPanel p1, p2;
	
	Payment(String namename, String num_count){
		setTitle("결제자 인증");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new GridLayout(2, 1));
		
		setVisible(true);		
		setSize(300,200);
		
			try {
				con = dbconnect.getdbconnect();
				st = con.createStatement();
				
				ResultSet re = st.executeQuery("select memberNo from member");
				
				while(re.next()) {
					String num = re.getString("memberNo");
					memberNo_box.addItem(num);
				}	
			}
			
			catch(Exception e) {
				e.printStackTrace();
			}
		
		p1 = new JPanel();
		p1.setLayout(new GridLayout(2, 2));
		
		p2 = new JPanel();
		p2.setLayout(new FlowLayout());
		
		
		memberNo = new JLabel("사원번호");
		
		passwd = new JLabel("패스워드");
		tf1 = new JTextField(10);
		
		yes = new JButton("예(Y)");
		no = new JButton("아니오(N)");
		
		p1.add(memberNo);
		p1.add(memberNo_box);
		p1.add(passwd);
		p1.add(tf1);
		
		p2.add(yes);
		p2.add(no);

		c.add(p1);
		c.add(p2);
		
		yes.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					con = dbconnect.getdbconnect();
					st = con.createStatement();
				
					psmt = con.prepareStatement("select memberNo from member Where memberNo=? and passwd=?");
					
					String DB_no = memberNo_box.getSelectedItem().toString();
					String DB_pw = tf1.getText();
					
					psmt.setString(1, DB_no);
					psmt.setString(2, DB_pw);
					
					ResultSet rs = psmt.executeQuery();
					
					if(rs.next()) {
							try {
								con = dbconnect.getdbconnect();
								st = con.createStatement();
							
								psmt = con.prepareStatement("UPDATE meal SET maxCount = maxCount -? WHERE mealName= ?");
							
								psmt.setString(1, num_count);
								psmt.setString(2, namename);
								psmt.executeUpdate();
								
								JOptionPane.showMessageDialog(null, "결제가 완료되었습니다.\n식권을 출력합니다.", "Message", JOptionPane.INFORMATION_MESSAGE);
							}
							
							catch(SQLException e1) {
								e1.printStackTrace();
							}
					}
					
					
					else  {
						JOptionPane.showMessageDialog(null, "패스워드가 일치하지 않습니다.", "Message", JOptionPane.ERROR_MESSAGE);
					}
					
					rs.close();
					psmt.close();
					con.close();
					
				} 
				
				catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		});
		
		
		no.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
	}
}
