package meal;

public class Runnable {
	public static void main(String[] args) {
//		new create_db();
//		new create_table();
//		new insert_data();
		new main();
	}
}
