package meal;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class insert_data {
	
	Statement st = null;
	Connection con =null;	
	PreparedStatement psmt = null;
	
	Scanner read_file;
	
	insert_data(){
		
		String tables [] = {"member","cuisine","meal", "orderlist"};
		String insert_tables;
		String line = null;
	
		String tmp = null;
		
		String member_insert = "insert into member values (?, ?, ?)";
		String cuisine_insert = "insert into cuisine values (?, ?)";
		String meal_insert = "insert into meal values (?, ?, ?, ?, ?, ?)";
		String orderlist_insert = "insert into orderlist values (?, ?, ?, ?, ?, ?,?)";
		
		int i=0;
		int j=0;
		
		try {
			con = dbconnect.getdbconnect();
			st = con.createStatement();
			
			for(i = 0; i < tables.length; i++) {
				
				if(tables[i].equals("member")) {
					tmp = member_insert;					
				}
				
				if(tables[i].equals("cuisine")) {
					tmp = cuisine_insert;					
				}
				
				if(tables[i].equals("meal")) {
					tmp = meal_insert;					
				}
				
				if(tables[i].equals("orderlist")) {
					tmp = orderlist_insert;					
				}
				
				read_file = new Scanner(new FileInputStream("txt\\"+tables[i]+".txt"));
				line = read_file.nextLine();
				
					while(read_file.hasNext()) {	 
					String b [] = read_file.nextLine().split("\t");	
					psmt = con.prepareStatement(tmp);
						for(j=0;j<b.length;j++) {
							psmt.setString(j+1, b[j]);
						}	
						psmt.executeUpdate();
					}
			}
			
				System.out.println("insert data OK.");
		}
	
		catch(SQLException e) {
			System.out.println("SQL Err");
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			System.out.println("Not Found File");
			e.printStackTrace();
		}
	}
}
