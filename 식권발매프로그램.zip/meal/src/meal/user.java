package meal;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Calendar;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;



class TimerThread extends Thread{
	JLabel timerLabel;
	
	public TimerThread(JLabel timerLabel) {
		this.timerLabel = timerLabel;
	}
	
	public void run() {
		while(true) {
		
			Calendar c = Calendar.getInstance();
			int hour = c.get(Calendar.HOUR_OF_DAY);
			int min = c.get(Calendar.MINUTE);
			int second = c.get(Calendar.SECOND);
			
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH);
			int day = c.get(Calendar.DAY_OF_MONTH);
			
	
			String clockText = Integer.toString(year);
			clockText = clockText.concat("년");
			clockText = clockText.concat(Integer.toString(month));
			clockText = clockText.concat("월");
			clockText = clockText.concat(Integer.toString(day));
			clockText = clockText.concat("일");
			
			clockText = clockText.concat(Integer.toString(hour));
			clockText = clockText.concat("시");
			clockText = clockText.concat(Integer.toString(min));
			clockText = clockText.concat("분");
			clockText = clockText.concat(Integer.toString(second));
			clockText = clockText.concat("초");
			
			timerLabel.setText(clockText);
			timerLabel.setForeground(Color.WHITE);
	
			try {
				Thread.sleep(1000);
			}catch(InterruptedException e) {
				return;
			}	
		}
	}	
}





public class user extends JFrame{

	JLabel logo_name, time;
	JLabel j_img[] = new JLabel[4];
	
	JTabbedPane tb;
	
	JPanel p1,p2,p3,tbp;
	
	ImageIcon img[] = {
			new ImageIcon("imgs/menu_1.png"),
			new ImageIcon("imgs/menu_2.png"),
			new ImageIcon("imgs/menu_3.png"),
			new ImageIcon("imgs/menu_4.png")};
	
	user(){
		setTitle("식권 발매 프로그램");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		
		logo_name = new JLabel("식권 발매 프로그램");
		logo_name.setFont(new Font("맑은 고딕",Font.BOLD, 20));
		
		time = new JLabel();
		time.setFont(new Font("맑은고딕",Font.BOLD, 15));
		
		TimerThread th = new TimerThread(time);
		
		p1 = new JPanel();
		p2 = new JPanel();
		p3 = new JPanel();
		tbp = new JPanel();
		tbp.setLayout(new GridLayout(2, 2));
		
		for(int i = 0; i < img.length; i++) {
			Mouselistener ms = new Mouselistener();
			
			j_img[i] = new JLabel(img[i]);
			j_img[i].addMouseListener(ms);
			
			tbp.add(j_img[i]);
		}
			
		j_img[0].setToolTipText("한식");	
		j_img[1].setToolTipText("중식");
		j_img[2].setToolTipText("일식");
		j_img[3].setToolTipText("양식");
		
		tb = new JTabbedPane();
		tb.addTab("메뉴", tbp);
		
		p1.add(logo_name);
		p2.add(time);
		p2.setBackground(Color.BLACK);
		p2.setForeground(Color.white);
		
		c.add(p1,BorderLayout.NORTH);
		c.add(tb,BorderLayout.CENTER);
		c.add(p2,BorderLayout.SOUTH);
		
		setVisible(true);
		setSize(450, 700);
		
		th.start();		
	}
	
	class Mouselistener extends MouseAdapter{
		public void mousePressed(MouseEvent e){
			   if(e.getSource()== j_img[0]) {
				   new food_selector(1);
				   dispose();
			   	}
			   
			   else if(e.getSource()== j_img[1]) {
				   new food_selector(2);
				   dispose();
			   	}
			   
			   else if(e.getSource()== j_img[2]) {
				   new food_selector(3);
				   dispose();
			   	}
			   
			   else if(e.getSource()== j_img[3]) {
				   new food_selector(4);
				   dispose();
			   	}
		}
	}
}
