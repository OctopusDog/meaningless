package meal;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;



public class food_selector extends JFrame{
	int sum=0;
	String num_count;
	String all_cash;
	String food_title;
	String name=null;
	
	JButton A;
	
	Statement st =  null;
	Connection con = null;
	
	PreparedStatement psmt = null;

	JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	
	JPanel p2_p3 = new JPanel();
	
	JPanel p3_top = new JPanel();
	JPanel p3_left = new JPanel();
	JPanel p3_right = new JPanel();
	JPanel p3_center = new JPanel();
	JPanel p3_center_center = new JPanel();
	JPanel p3_bottom = new JPanel();
	String row_name_s;
	String namename;
	
	JLabel title, all_cash_label, cash, select_mealName, meal_count;
	
	JTable jt;
	
	JTextField jf1, jf2;
	
	JButton insert, Payment ,close;


	
	Vector<String> colData = new Vector<String>();
	Vector<Vector <String>>rowData = new Vector<Vector<String>>();
	
	Vector<btn> save_btn = new Vector<btn>();
	Vector<String>name_select = new Vector<String>();

	public class create_btn{	
		Statement st = null;
		Connection con = null ;
		PreparedStatement psmt = null;
		
		create_btn(Integer num){	
			try {
				con = dbconnect.getdbconnect();
				st = con.createStatement();

				psmt = con.prepareStatement("Select mealName, price from meal where maxCount>=1 AND todayMeal = 1 AND cuisineNo = ?");
				psmt.setString(1, num.toString());
			
				ResultSet rs = psmt.executeQuery();
				int index = 0;
				while(rs.next()) {
					
					String mealName = rs.getString(1);
					String price = rs.getString(2);
					
					save_btn.add(new btn(mealName, price));
					p2.add(save_btn.get(index));
					
					name_select.add(mealName);
					
					index++;
				}				
			}
				catch(SQLException e) {
					e.printStackTrace();
			}
		}
	}
	public class btn extends JButton{
		
		Vector<String> price_add = new Vector<String>();
		btn(String mealName, String price){
	
			
			this.setText(mealName+"("+price+")");
			this.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent ee) {
					A = (JButton)ee.getSource();
					A.setEnabled(false);
					jf1.setText(mealName);	
					
					}
				});
			}
		}
	
		food_selector(int num){
			setTitle("결제");
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
			Container c = getContentPane();
			c.setLayout(new BorderLayout());
			
			colData.add("상품번호");
			colData.add("품명");
			colData.add("수량");
			colData.add("금액");
			
			jt = new JTable(rowData, colData);
			JScrollPane jps = new JScrollPane(jt);
			
			
		
			switch (num) {
			case 1: food_title = "한식";
					break;
					
			case 2: food_title = "중식";
					break;		
					
			case 3: food_title = "일식";
					break;
					
			case 4: food_title = "양식";
					break;
					
			default:
					break;
			}
			
			title = new JLabel(food_title);
			title.setFont(new Font("맑은고딕",Font.BOLD, 30));
			
			all_cash_label = new JLabel("총결제금액:");
			all_cash_label.setFont(new Font("맑은고딕",Font.BOLD, 20));
			
			cash = new JLabel(all_cash+" 원");
			cash.setFont(new Font("맑은고딕",Font.BOLD, 20));
			
			select_mealName = new JLabel("선택품명:");
			meal_count = new JLabel("수량:");
			
			jf1 = new JTextField(25);
			jf1.setEnabled(false);
			jf2 = new JTextField(5);
			
			insert = new JButton("입력");
			Payment = new JButton("결제");
			close = new JButton("닫기");
			
			p2_p3.setLayout(new GridLayout(1, 2));
					
			p1.add(title);
			p2.setLayout(new GridLayout(5, 5));
			p3.setLayout(new BorderLayout());
					
			p3_top.setLayout(new GridLayout(1, 2));
			
			p3_left.add(all_cash_label);
			p3_right.add(cash);
			
			p3_top.add(p3_left,BorderLayout.WEST);
			p3_top.add(p3_right,BorderLayout.EAST);
					
			p3_center_center = new JPanel();
			p3_center_center.setLayout(new GridLayout(3, 1));
			
			p3_center.setLayout(new FlowLayout());
			p3_center.add(select_mealName);
			p3_center.add(jf1);
			p3_center.add(meal_count);
			p3_center.add(jf2);
			
			p3_bottom.setLayout(new FlowLayout());
			p3_bottom.add(insert);
			p3_bottom.add(Payment);
			p3_bottom.add(close);
			
			p3_center_center.add(p3_center);
			p3_center_center.add(p3_bottom);
			
			p3.add(p3_top,BorderLayout.NORTH);
			p3.add(jps,BorderLayout.CENTER);
			p3.add(p3_center_center,BorderLayout.SOUTH);
			
			
			p2_p3.add(p2);
			p2_p3.add(p3);
			
			c.add(p1,BorderLayout.NORTH);
			c.add(p2_p3,BorderLayout.SOUTH);
			
			new create_btn(num);
			
			jt.addMouseListener(new MouseAdapter() {
				
				@Override
				public void mousePressed(MouseEvent e) {
										
					if(e.getClickCount() == 2) {
						System.out.println("두번클릭");
						  
						  int row_name = jt.getSelectedRow();
						  row_name_s = jt.getValueAt(row_name, 1).toString();
						  
						  for(int i = 0; i<save_btn.size();i++) {
							  String n = name_select.get(i);					  
							  
							  if(row_name_s.equals(n)) {
								  save_btn.get(i).setEnabled(true);
							  }
						  }
						  	
					     
						  int row= jt.getSelectedRow(); 	
						  String s = (String)jt.getValueAt(row, 3);
						  sum-=Integer.parseInt(s);
						  
						  all_cash = String.format("%,d", sum);
						  cash.setText(all_cash+" 원");
						  
						  DefaultTableModel m = (DefaultTableModel)jt.getModel();
						  m.removeRow(row);		  
						}  
					}
				});	
			
			
			close.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			
			setSize(1800, 680);
			setVisible(true);	
			
			//결제 버튼 
			Payment.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					new Payment(namename, num_count);
					
				}
			});
			
			insert.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {	
					try {
						con = dbconnect.getdbconnect();
						st = con.createStatement();

						psmt = con.prepareStatement("select mealNo, price, maxCount from meal where mealName=?");
						psmt.setString(1, jf1.getText());
						
						ResultSet rs = psmt.executeQuery();
						
						num_count = jf2.getText();
						namename = jf1.getText();
						
						
						while(rs.next()) {
							
							if(num_count.equals("") || num_count.equals("0")) {
								JOptionPane.showMessageDialog(null, "수량을 입력해주세요.", "Message",JOptionPane.ERROR_MESSAGE );
							}
						
							
							else if(Integer.parseInt(num_count)>=50) {
								JOptionPane.showMessageDialog(null, "조리가능수량이 부족합니다.", "Message",JOptionPane.ERROR_MESSAGE );
								all_cash = "0";
							}
							
							else {	
								Vector<String> v = new Vector<String>();
								int jt_count = Integer.parseInt(rs.getString(2))*Integer.parseInt(num_count);
								
								v.add(rs.getString(1));
								v.add(jf1.getText());
								v.add(jf2.getText());
								v.add(Integer.toString(jt_count));
								rowData.add(v);
								
								sum+= Integer.parseInt(rs.getString(2))*Integer.parseInt(num_count);
								all_cash = String.format("%,d", sum);
								cash.setText(all_cash+" 원");
							}	
						}
							jt.updateUI();
					}
					
					catch(Exception ee) {
						System.out.println(ee);
					}
				}
			});
		}
}

