package meal;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class menu_orderlist extends JFrame{
	String sql;
	
	Vector<String> colData = new Vector<String>();
	Vector<Vector <String>>rowData = new Vector<Vector<String>>();
	
	JTable jt;
	
	Statement st =  null;
	Connection con = null;
	PreparedStatement psmt = null;
	
	JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	
	String num;
	
	String menu;
	
	JLabel sum = new JLabel("합계: "+num+"개");
	JButton close = new JButton("닫기");
	
	menu_orderlist(){
		setTitle("메뉴별 주문현황");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setSize(300, 300);
		
		Container c = getContentPane();
		
		colData.add("종류");
		colData.add("주문수량");
		
		jt = new JTable(rowData, colData);
		JScrollPane jps = new JScrollPane(jt);
		
		p1.setLayout(new BorderLayout());
		p3.setLayout(new BorderLayout());
		
		p1.add(close,BorderLayout.EAST);
		p2.add(jps);
		p3.add(sum,BorderLayout.EAST);
		
		try {
			String sss = "select sum(ordereCount) from orderlist";
	
			Connection con = dbconnect.getdbconnect();
			Statement stmt = con.createStatement();
			ResultSet  r1 = stmt.executeQuery(sss);
			
			
			
			while(r1.next()) {

				num = r1.getString(1);
				sum.setText("합계: "+num+"개");
			}
	
			
		}
		
		catch(SQLException e){
			e.printStackTrace();
		}

		
		try {
			rowData.clear();	
			for(int i = 1; i<5; i++) {
				
				sql = "select cuisineNo, sum(ordereCount) from orderlist where cuisineNo = "+i;
				
				Connection con = dbconnect.getdbconnect();
				Statement stmt = con.createStatement();
				ResultSet  rs = stmt.executeQuery(sql);
				
				jt.setAutoCreateRowSorter(true);
				TableRowSorter talbesorter = new TableRowSorter<TableModel>(jt.getModel());
				jt.setRowSorter(talbesorter);
				
				while(rs.next()) {
					
					Vector<String> v = new Vector<String>();
					if(rs.getString(1).equals("1")) {
						menu = "한식";
						v.add(menu);
						v.add(rs.getString(2));
					}
					
					else if(rs.getString(1).equals("2")){
						menu = "중식";
						v.add(menu);
						v.add(rs.getString(2));

					}
					
					else if(rs.getString(1).equals("3")){
						menu = "일식";
						v.add(menu);
						v.add(rs.getString(2));

					}
					
					else if(rs.getString(1).equals("4")){
						menu = "양식";
						v.add(menu);
						v.add(rs.getString(2));
					}
					
					
					rowData.add(v);
				}
				jt.updateUI();
			}
		}
		
		catch(SQLException e1) {
			e1.printStackTrace();
		}
		
		close.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		c.add(p1,BorderLayout.NORTH);
		c.add(jps,BorderLayout.CENTER);
		c.add(p3,BorderLayout.SOUTH);
	}
}
