package meal;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class menu_add extends JFrame{
	
	JLabel kind, menu_name, price, maxCount;
	JPanel p1, p2, p3, p4, p5;
	JPanel p1_1;
	
	JTextField f1;
	
	JComboBox kind_box = new JComboBox();
	JComboBox price_box = new JComboBox();
	JComboBox maxCount_box = new JComboBox();
	
	JButton add, exit;
	
	Statement st =  null;
	Connection con = null;
	
	PreparedStatement psmt = null;
	int num = 0;

	menu_add(){
		setTitle("신규 메뉴 등록");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		
		Container c = getContentPane();
		c.setLayout(new GridLayout(5, 2));
		
		
		for(int i=1000;i<=12000;i+=500) {
			price_box.addItem(i);
		}
		
		for(int i=0;i<=50;i++) {
			maxCount_box.addItem(i);
		}


		try {
			con = dbconnect.getdbconnect();
			st = con.createStatement();
			
			ResultSet re = st.executeQuery("select cuisineName from cuisine");
			
			while(re.next()) {
				String cuisineName = re.getString("cuisineName");
				kind_box.addItem(cuisineName);
			}	
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
		
			
		kind = new JLabel("종류");
		menu_name = new JLabel("메뉴명");
		price = new JLabel("가격");
		maxCount = new JLabel("조리가능수량");
		
		p1 = new JPanel(new GridLayout(1, 2));
		p2 = new JPanel(new GridLayout(1, 2));
		p3 = new JPanel(new GridLayout(1, 2));
		p4 = new JPanel(new GridLayout(1, 2));
		p5 = new JPanel(new GridLayout(1, 2));
		
		f1 = new JTextField(10);
		
		add = new JButton("등록");
		exit = new JButton("닫기");
		
		
		exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				
			}
		});
		
		add.addActionListener(new ActionListener() {		
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(f1.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "메뉴명을 확인 해주세요.", "Message", JOptionPane.ERROR_MESSAGE);
				}
				
				else {
					try {
						
						con = dbconnect.getdbconnect();
						st = con.createStatement();
						
						psmt = con.prepareStatement("insert into meal values (?, ?, ?, ?, ?, ?)");
						
						ResultSet re = st.executeQuery("select max(mealNo) from meal");
						
						while(re.next()) {
							num = re.getInt("max(mealNo)");
						}
						
						num+=1;

						int kind_db = kind_box.getSelectedIndex();
						kind_db+=1;
						
						int price_db = (int) price_box.getSelectedItem();
						int maxCount_db = (int) maxCount_box.getSelectedItem();
						
						psmt.setInt(1, num);
						psmt.setInt(2, kind_db);
						psmt.setString(3, f1.getText());
						psmt.setInt(4, price_db);
						psmt.setInt(5, maxCount_db);
						psmt.setInt(6, 0);

						int rs = psmt.executeUpdate();
						
						if(rs == 1){
							JOptionPane.showMessageDialog(null, "메뉴가 등록되었습니다.", "Message", JOptionPane.INFORMATION_MESSAGE);
						}
						
					
						
					}
					
					catch(Exception e22) {
						e22.printStackTrace();
					}

				}
				
								
			}	
		});
		
		p1.add(kind);
		p1.add(kind_box);
		
		p2.add(menu_name);
		p2.add(f1);
		
		p3.add(price);
		p3.add(price_box);
		
		p4.add(maxCount);
		p4.add(maxCount_box);
		
		p5.add(add);
		p5.add(exit);
		
		
		c.add(p1);
		c.add(p2);
		c.add(p3);
		c.add(p4);
		c.add(p5);
		
		setSize(500, 380);
		setVisible(true);

		
	}
}
