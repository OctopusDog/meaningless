package meal;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class create_db {
	
	
	Statement st = null;
	Connection con = null ;
	
	create_db(){
		try {
			con = dbconnect.getdbconnect();
			st = con.createStatement();
			
			st.executeUpdate("create database if not exists meal"); 
			System.out.println("Create Database OK.");
			
		}catch(SQLException e) {
			System.out.println("Err");
		}		
	}	
}
