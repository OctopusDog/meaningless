package meal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.plaf.synth.SynthSeparatorUI;

public class dbconnect {
	public static Connection getdbconnect(){
			
		String url = "jdbc:mysql://localhost:3306/meal?characterEncoding=UTF-8&serverTimezone=UTC";
		String id = "root";
		String pw = "1234";
		Connection con = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, id, pw);
			System.out.println("OK.");
			return con;
		}
		
		catch(ClassNotFoundException e) {
			System.out.println("Err");
		}
		
		catch(SQLException e) {
			e.printStackTrace();
		}return null;
	}
}
