package meal;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.plaf.synth.SynthSeparatorUI;

public class main extends JFrame{
	
	JButton member_add, user, admin, exit;
	
	main(){
		setTitle("메인");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new GridLayout(4, 1));
		
		member_add = new JButton("사원등록");
		user = new JButton("사용자");
		admin = new JButton("관리자");
		exit = new JButton("종료");
		
		member_add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new member_add();
			}
		});
		
		exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("System Stop");
				System.exit(0);
			}
		});
		
		user.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new user();
			}
		});
		
		admin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new admin();
				
			}
		});
		
		c.add(member_add);
		c.add(user);
		c.add(admin);
		c.add(exit);
		
		setVisible(true);
		setSize(300, 300);
	}
}
