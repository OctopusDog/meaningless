package meal;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class member_add extends JFrame{
	
	JLabel num, name, pwd, pwd_re;
	JButton add, close;
	
	JTextField f1, f2;	
	JPasswordField f3, f4;
	
	String pwd_s;
	String pwd_ree;
	
	Statement st = null;
	Connection con =null;	
	PreparedStatement psmt = null;
	
	String num_db;
	String name_db;
	
	member_add(){
		setTitle("사원등록");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new GridLayout(5, 2));
		
		num = new JLabel("사원번호:");
		name = new JLabel("사원명:");
		pwd = new JLabel("패스워드:");
		pwd_re = new JLabel("패스워드 재입력:");
		
		f1 = new JTextField(10);
		f1.enable(false);
		f2 = new JTextField(10);
		
		f3 = new JPasswordField(10);
		f4 = new JPasswordField(10);
		
		f3.setEchoChar('●');
		f4.setEchoChar('●');

		
		add = new JButton("등록");
		close = new JButton("닫기");
		
		try {
			con = dbconnect.getdbconnect();
			st = con.createStatement();
			
			ResultSet re = st.executeQuery("select MAX(memberNo)from member");

			
			while(re.next()) {
				Integer memberNo = re.getInt(1);
				memberNo+=1;
				f1.setText(memberNo.toString());
			}
			

		}
		
		catch(SQLException e){
			e.printStackTrace();
		}
			
		add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				num_db = f1.getText();
				name_db = f2.getText();					
				pwd_s = new String(f3.getPassword());
				pwd_ree = new String(f4.getPassword());
				
				
				if(!pwd_s.equals(pwd_ree)) {
					JOptionPane.showMessageDialog(null, "패스워드 확인 요망.", "Message", JOptionPane.ERROR_MESSAGE);
				}
				
				
				if(num_db.equals("") || name_db.equals("") || pwd_s.equals("") || pwd_ree.equals("")) 
				{
					JOptionPane.showMessageDialog(null, "항목누락.", "Message", JOptionPane.ERROR_MESSAGE);
				}
				else if(pwd_s.equals(pwd_ree)){

					try {
						
						con = dbconnect.getdbconnect();
						st = con.createStatement();
							
						psmt = con.prepareStatement("insert into member values(?, ?, ?)");
						
				
						System.out.println(pwd_s);
							
						psmt.setString(1, num_db);
						psmt.setString(2, name_db);
						psmt.setString(3, pwd_s);
						
						int rs = psmt.executeUpdate();
						
						if(rs == 1){
							JOptionPane.showMessageDialog(null, "사원이 등록되었습니다.", "Message", JOptionPane.INFORMATION_MESSAGE);
							}		
						
						} catch (SQLException e1) {		
							e1.printStackTrace();
					}		
				}
				
				
				
				
			}
		});
		
		close.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		c.add(num);
		c.add(f1);
		
		c.add(name);
		c.add(f2);
		
		c.add(pwd);
		c.add(f3);
		
		c.add(pwd_re);
		c.add(f4);
		
		c.add(add);
		c.add(close);
		
		setVisible(true);
		setSize(500, 300);
	}
}
