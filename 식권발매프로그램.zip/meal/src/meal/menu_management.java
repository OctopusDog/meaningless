package meal;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class menu_management extends JFrame{
	
	String todayMeal;
	String nnn;
	int a2;
	
	JPanel p1, p2;
	JButton all_select, search, edit, delete, today_menu_set, exit;
	
	JLabel kind = new JLabel("종류:");
	JComboBox kind_box = new JComboBox();

	Statement st =  null;
	Connection con = null;
	
	PreparedStatement psmt = null;
	
	
	Vector<String> colData = new Vector<String>();
	Vector<Vector <String>>rowData = new Vector<Vector<String>>();
	
	JTable jt;
	
	menu_management(){
		setTitle("메뉴 관리");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setSize(800, 800);
		
		Container c = getContentPane();
		
		view();
		
		try {
			con = dbconnect.getdbconnect();
			st = con.createStatement();
			
			ResultSet re = st.executeQuery("select cuisineName from cuisine");
			
			while(re.next()) {
				String cuisineName = re.getString("cuisineName");
				kind_box.addItem(cuisineName);
			}	
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
		
		colData.add("mealName");
		colData.add("price");
		colData.add("maxCount");
		colData.add("todayMeal");
	
		jt = new JTable(rowData, colData);
		JScrollPane jps = new JScrollPane(jt);
	
		all_select = new JButton("모두 선택");
		search = new JButton("검색");
		edit = new JButton("수정");
		delete = new JButton("삭제");
		today_menu_set = new JButton("오늘의 메뉴 선정");
		exit = new JButton("닫기");
		
		p1 = new JPanel();
		p2 = new JPanel();
		p2.setLayout(new GridLayout(1, 1));
		
		p1.add(all_select);
		p1.add(kind);
		p1.add(kind_box);
		p1.add(search);
		p1.add(edit);
		p1.add(delete);
		p1.add(today_menu_set);
		p1.add(exit);
		
		p2.add(jps);
		
		c.add(p1,BorderLayout.NORTH );
		c.add(p2,BorderLayout.CENTER);
		
		
		today_menu_set.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					con = dbconnect.getdbconnect();
					st = con.createStatement();
					
					int s = jt.getSelectedRow();
					String a1 = (String) jt.getValueAt(s, 0);
					
					ResultSet re = st.executeQuery("select todayMeal from meal where mealName ="+"'"+a1+"'");
					
					while(re.next()) {
						nnn = re.getString("todayMeal");
					}
					
					
					psmt = con.prepareStatement("update meal set todayMeal = ? where mealName = ?");
					
					System.out.println(todayMeal);
					
					if(nnn.equals("1")) {
						a2 = 0;
			
					}
					else if(nnn.equals("0")) {
						a2 = 1;
		
					}
					
					System.out.println(a2);
					
					psmt.setInt(1, a2);
					psmt.setString(2, a1);

					int rs = psmt.executeUpdate();
					
					JOptionPane.showMessageDialog(null, "수정이 완료되었습니다.", "메시지", JOptionPane.INFORMATION_MESSAGE);
					
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		
		delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				delete();
			}
		});
		
		exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {	
				dispose();
			}
		});
		
		search.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				search();
			}
		});
		
		edit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Vector<String> v_edit = new Vector<String>();
				int s = jt.getSelectedRow();
				
				String a1 = (String) jt.getValueAt(s, 0);
							
				new edit(a1);				
			}
		});
		
			
	}
	
	private void delete(){	
	try {
	
		Vector<String> v_edit = new Vector<String>();
		con = dbconnect.getdbconnect();
		st = con.createStatement();
		psmt = con.prepareStatement("delete from meal where mealName = ?");
			
		int s = jt.getSelectedRow();
		String a1 = (String) jt.getValueAt(s, 0);
		psmt.setString(1, a1);

		int rs = psmt.executeUpdate();
		
		JOptionPane.showMessageDialog(null, "삭제가 완료되었습니다.", "메시지", JOptionPane.ERROR_MESSAGE);
		

	} catch (SQLException e1) {
		e1.printStackTrace();
	}
}
	
	
	
	private void search() {
		rowData.clear();
		
		int iname = kind_box.getSelectedIndex();
		iname+=1;

		String sql = "select mealName, price, maxCount, todayMeal from meal where cuisineNo = "+iname;
		
		try {	
			
		Connection con = dbconnect.getdbconnect();
		Statement stmt = con.createStatement();
		ResultSet re = stmt.executeQuery(sql);
		
		while(re.next()) {
			Vector<String> v = new Vector<String>();
			
			v.add(re.getString(1));
			v.add(re.getString(2));
			v.add(re.getString(3));
			
			if(re.getString(4).equals("1")) {
				todayMeal = "Y";
				v.add(todayMeal);
			}
			
			else{
				todayMeal = "N";
				v.add(todayMeal);
			}
				rowData.add(v);
			}
		
			jt.updateUI();	
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private void view() {
		String sql = "select mealName, price, maxCount, todayMeal from meal";
		try {
			rowData.clear();
			Connection con = dbconnect.getdbconnect();
			Statement stmt = con.createStatement();
			ResultSet  rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				Vector<String> v = new Vector<String>();
				
				v.add(rs.getString(1));
				v.add(rs.getString(2));
				v.add(rs.getString(3));
				
				if(rs.getString(4).equals("1")) {
					todayMeal = "Y";
					v.add(todayMeal);
				}
				
				else{
					todayMeal = "N";
					v.add(todayMeal);

				}
				rowData.add(v);
			}
			
			jt.updateUI();
		}catch(Exception ee) {System.out.println(ee);}
	}
	
}
