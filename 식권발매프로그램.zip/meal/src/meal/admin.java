package meal;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class admin extends JFrame{
	
	JPanel p1, p2;
	JButton menu_add, menu_management, cash_lookup, menu_orderlist ,exit;
	JLabel img_Label;

	
	admin(){
		setTitle("관리");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setSize(600, 500);
		
		Container c = getContentPane();
		
		p1 = new JPanel();
		p2 = new JPanel();
		
		menu_add = new JButton("메뉴등록");
		menu_management = new JButton("메뉴관리");
		cash_lookup = new JButton("결제조회");
		menu_orderlist = new JButton("메뉴별 주문현황");
		exit = new JButton("종료");
		
		img_Label = new JLabel(new ImageIcon("imgs\\main.jpg"));
			
		p1.add(menu_add);
		p1.add(menu_management);
		p1.add(cash_lookup);
		p1.add(menu_orderlist);
		p1.add(exit);
		
		p2.add(img_Label);
		
		c.add(p1,BorderLayout.NORTH );
		c.add(p2,BorderLayout.CENTER);
		
		menu_orderlist.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new menu_orderlist();
			}
		});
		
		cash_lookup.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new cash_lookup();
			}
		});

		exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		menu_add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new menu_add();
				
			}
		});
		
		menu_management.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new menu_management();
			}
		});
		
		
		
	}
}
